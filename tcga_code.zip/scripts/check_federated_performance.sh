#!/bin/bash
# Script to check federated learning performance metrics

WORKSPACE=${1:-outputs/nvflare_workspace}

echo "=== Federated Learning Performance Metrics ==="
echo ""

# Check server log
if [ -f "${WORKSPACE}/server/log.txt" ]; then
    echo "--- Server Log (Last 50 lines) ---"
    tail -50 "${WORKSPACE}/server/log.txt" | grep -E "Round|metrics|accuracy|loss|val|test" | tail -20
    echo ""
fi

# Check each site's log
for site_id in 1 2 3; do
    site_log="${WORKSPACE}/site-${site_id}/log.txt"
    if [ -f "$site_log" ]; then
        echo "--- Site ${site_id} Log (Last 30 lines with metrics) ---"
        tail -100 "$site_log" | grep -E "Round|metrics|accuracy|loss|val|test" | tail -15
        echo ""
    fi
done

# Check meta.json for job info
if [ -f "${WORKSPACE}/server/simulate_job/meta.json" ]; then
    echo "--- Job Metadata ---"
    python3 << PYTHON_EOF
import json
from pathlib import Path

meta_path = Path("${WORKSPACE}/server/simulate_job/meta.json")
if meta_path.exists():
    with open(meta_path) as f:
        meta = json.load(f)
    print(f"Job name: {meta.get('name', 'N/A')}")
    print(f"Status: {meta.get('status', 'N/A')}")
    print(f"Start time: {meta.get('start_time', 'N/A')}")
    print(f"End time: {meta.get('end_time', 'N/A')}")
PYTHON_EOF
    echo ""
fi

echo "=== To view real-time logs, use: ==="
echo "  tail -f ${WORKSPACE}/server/log.txt | grep -E 'Round|metrics|accuracy'"


