#!/usr/bin/env python3
"""
BRCA 데이터셋 검증 스크립트

새로운 BRCA-data-with-integer-labels.csv와 기존 Xena RNA-seq 데이터셋을 비교하여
일치 여부를 확인합니다.
"""
import argparse
import gzip
import logging
import sys
from pathlib import Path
from typing import Dict, Set, Tuple

import numpy as np
import pandas as pd
from tqdm import tqdm

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def extract_patient_id(sample_barcode: str) -> str:
    """TCGA 샘플 바코드에서 Patient ID 추출 (첫 12자)"""
    parts = sample_barcode.split("-")
    if len(parts) >= 3:
        return "-".join(parts[:3])
    return sample_barcode


def load_new_dataset(csv_path: str) -> pd.DataFrame:
    """새로운 BRCA 데이터셋 로드"""
    logger.info(f"Loading new dataset: {csv_path}")
    df = pd.read_csv(csv_path)
    logger.info(f"  Shape: {df.shape}")
    logger.info(f"  Columns: {len(df.columns)}")
    logger.info(f"  Samples: {len(df)}")
    
    # 첫 번째 컬럼이 sample_id인지 확인
    if df.columns[0] != 'sample_id':
        logger.warning(f"First column is '{df.columns[0]}', expected 'sample_id'")
    
    return df


def load_xena_expression_header(tsv_path: str) -> Tuple[list, int]:
    """Xena expression 파일의 헤더와 유전자 수 확인"""
    logger.info(f"Loading Xena expression header: {tsv_path}")
    
    # 헤더 읽기
    with gzip.open(tsv_path, 'rt') if tsv_path.endswith('.gz') else open(tsv_path, 'rt') as f:
        header = f.readline().strip().split('\t')
    
    # 유전자 수 계산 (헤더 제외)
    gene_id_col = header[0]
    sample_columns = header[1:]
    
    logger.info(f"  Gene ID column: {gene_id_col}")
    logger.info(f"  Sample columns: {len(sample_columns)}")
    
    # 유전자 수 확인 (전체 파일 스캔)
    n_genes = 0
    with gzip.open(tsv_path, 'rt') if tsv_path.endswith('.gz') else open(tsv_path, 'rt') as f:
        f.readline()  # 헤더 스킵
        for line in f:
            n_genes += 1
    
    logger.info(f"  Total genes: {n_genes}")
    
    return header, n_genes


def load_xena_gene_ids(tsv_path: str, max_genes: int = None) -> list:
    """Xena 파일에서 유전자 ID 리스트 추출"""
    logger.info(f"Extracting gene IDs from Xena file...")
    gene_ids = []
    
    with gzip.open(tsv_path, 'rt') if tsv_path.endswith('.gz') else open(tsv_path, 'rt') as f:
        f.readline()  # 헤더 스킵
        for i, line in enumerate(f):
            if max_genes and i >= max_genes:
                break
            gene_id = line.strip().split('\t')[0]
            gene_ids.append(gene_id)
    
    logger.info(f"  Extracted {len(gene_ids)} gene IDs")
    return gene_ids


def compare_samples(
    new_df: pd.DataFrame,
    xena_samples: list
) -> Dict[str, any]:
    """샘플 ID 비교"""
    logger.info("=" * 60)
    logger.info("Comparing sample IDs...")
    
    new_samples = set(new_df['sample_id'].values)
    xena_samples_set = set(xena_samples)
    
    # Patient ID로 변환
    new_patients = set(extract_patient_id(s) for s in new_samples)
    xena_patients = set(extract_patient_id(s) for s in xena_samples_set)
    
    # 직접 매칭
    exact_matches = new_samples & xena_samples_set
    new_only = new_samples - xena_samples_set
    xena_only = xena_samples_set - new_samples
    
    # Patient ID 매칭
    patient_matches = new_patients & xena_patients
    new_patients_only = new_patients - xena_patients
    xena_patients_only = xena_patients - new_patients
    
    results = {
        'new_samples': len(new_samples),
        'xena_samples': len(xena_samples_set),
        'exact_sample_matches': len(exact_matches),
        'new_samples_only': len(new_only),
        'xena_samples_only': len(xena_only),
        'new_patients': len(new_patients),
        'xena_patients': len(xena_patients),
        'patient_matches': len(patient_matches),
        'new_patients_only': len(new_patients_only),
        'xena_patients_only': len(xena_patients_only),
    }
    
    logger.info(f"  New dataset samples: {results['new_samples']}")
    logger.info(f"  Xena dataset samples: {results['xena_samples']}")
    logger.info(f"  Exact sample matches: {results['exact_sample_matches']}")
    logger.info(f"  New samples only: {results['new_samples_only']}")
    logger.info(f"  Xena samples only: {results['xena_samples_only']}")
    logger.info("")
    logger.info(f"  New dataset patients: {results['new_patients']}")
    logger.info(f"  Xena dataset patients: {results['xena_patients']}")
    logger.info(f"  Patient matches: {results['patient_matches']}")
    logger.info(f"  New patients only: {results['new_patients_only']}")
    logger.info(f"  Xena patients only: {results['xena_patients_only']}")
    
    if results['exact_sample_matches'] > 0:
        logger.info(f"\n  Example exact matches: {list(exact_matches)[:5]}")
    if new_only:
        logger.info(f"\n  Example new-only samples: {list(new_only)[:5]}")
    if xena_only:
        logger.info(f"\n  Example xena-only samples: {list(xena_only)[:5]}")
    
    return results


def load_gene_mapping(probe_map_path: str) -> Dict[str, str]:
    """Gene mapping file 로드 (Ensembl ID -> Gene Symbol)"""
    logger.info(f"Loading gene mapping from: {probe_map_path}")
    mapping = {}
    
    try:
        df_map = pd.read_csv(probe_map_path, sep='\t')
        # 컬럼 이름 확인
        if 'id' in df_map.columns and 'gene' in df_map.columns:
            for _, row in df_map.iterrows():
                ensembl_id = str(row['id']).split('.')[0]  # 버전 제거
                gene_symbol = str(row['gene'])
                if pd.notna(gene_symbol) and gene_symbol:
                    mapping[ensembl_id] = gene_symbol
        elif len(df_map.columns) >= 2:
            # 첫 번째 컬럼이 ID, 두 번째가 Gene Symbol로 가정
            for _, row in df_map.iterrows():
                ensembl_id = str(row.iloc[0]).split('.')[0]
                gene_symbol = str(row.iloc[1])
                if pd.notna(gene_symbol) and gene_symbol:
                    mapping[ensembl_id] = gene_symbol
        
        logger.info(f"  Loaded {len(mapping)} gene mappings")
    except Exception as e:
        logger.warning(f"  Could not load gene mapping: {e}")
    
    return mapping


def compare_genes(
    new_df: pd.DataFrame,
    xena_gene_ids: list,
    gene_mapping: Dict[str, str] = None
) -> Dict[str, any]:
    """유전자 이름/ID 비교"""
    logger.info("=" * 60)
    logger.info("Comparing gene names/IDs...")
    
    # 새 데이터셋의 유전자 이름 (sample_id 제외)
    new_genes = set(new_df.columns[1:].tolist())
    
    # Xena 유전자 ID
    xena_genes = set(xena_gene_ids)
    
    # 직접 매칭
    exact_matches = new_genes & xena_genes
    new_only = new_genes - xena_genes
    xena_only = xena_genes - new_genes
    
    # Gene mapping을 통한 매칭 (있는 경우)
    mapped_matches = set()
    if gene_mapping:
        logger.info("  Attempting gene symbol mapping...")
        # Xena Ensembl ID -> Gene Symbol 변환
        xena_gene_symbols = {}
        for ensembl_id in xena_genes:
            # Ensembl ID에서 버전 제거
            base_id = ensembl_id.split('.')[0]
            if base_id in gene_mapping:
                symbol = gene_mapping[base_id]
                xena_gene_symbols[symbol] = ensembl_id
        
        # Gene Symbol로 매칭
        mapped_matches = new_genes & set(xena_gene_symbols.keys())
        logger.info(f"  Mapped matches (via gene symbols): {len(mapped_matches)}")
    
    total_matches = len(exact_matches) + len(mapped_matches)
    
    results = {
        'new_genes': len(new_genes),
        'xena_genes': len(xena_genes),
        'exact_matches': len(exact_matches),
        'mapped_matches': len(mapped_matches),
        'total_matches': total_matches,
        'new_genes_only': len(new_only),
        'xena_genes_only': len(xena_only),
        'match_ratio': total_matches / len(new_genes) if new_genes else 0,
    }
    
    logger.info(f"  New dataset genes: {results['new_genes']}")
    logger.info(f"  Xena dataset genes: {results['xena_genes']}")
    logger.info(f"  Exact gene matches: {results['exact_matches']}")
    if gene_mapping:
        logger.info(f"  Mapped gene matches (via symbols): {results['mapped_matches']}")
        logger.info(f"  Total matches: {results['total_matches']}")
    logger.info(f"  Match ratio: {results['match_ratio']:.2%}")
    logger.info(f"  New genes only: {results['new_genes_only']}")
    logger.info(f"  Xena genes only: {results['xena_genes_only']}")
    
    if exact_matches:
        logger.info(f"\n  Example exact matches: {list(exact_matches)[:10]}")
    if mapped_matches:
        logger.info(f"\n  Example mapped matches: {list(mapped_matches)[:10]}")
    if new_only:
        logger.info(f"\n  Example new-only genes: {list(new_only)[:10]}")
    if xena_only:
        logger.info(f"\n  Example xena-only genes: {list(xena_only)[:10]}")
    
    return results


def compare_values(
    new_df: pd.DataFrame,
    xena_path: str,
    common_samples: Set[str],
    common_genes: Set[str],
    n_samples_check: int = 10
) -> Dict[str, any]:
    """값 비교 (공통 샘플과 유전자에 대해)"""
    logger.info("=" * 60)
    logger.info("Comparing expression values...")
    
    if not common_samples or not common_genes:
        logger.warning("  No common samples or genes to compare")
        return {}
    
    # 공통 샘플 선택 (최대 n_samples_check개)
    samples_to_check = list(common_samples)[:n_samples_check]
    logger.info(f"  Checking {len(samples_to_check)} common samples")
    
    # Xena에서 해당 샘플들의 데이터 로드
    logger.info("  Loading Xena data for comparison...")
    
    with gzip.open(xena_path, 'rt') if xena_path.endswith('.gz') else open(xena_path, 'rt') as f:
        header = f.readline().strip().split('\t')
        sample_indices = {s: header.index(s) for s in samples_to_check if s in header}
        
        xena_data = {}
        for gene_id in tqdm(common_genes, desc="Loading genes", total=min(100, len(common_genes))):
            if len(xena_data) >= 100:  # 최대 100개 유전자만
                break
            line = f.readline()
            if not line:
                break
            fields = line.strip().split('\t')
            if fields[0] in common_genes:
                xena_data[fields[0]] = {
                    s: float(fields[idx]) if idx < len(fields) else np.nan
                    for s, idx in sample_indices.items()
                }
    
    # 새 데이터셋에서 값 추출
    new_data = {}
    for sample in samples_to_check:
        if sample in new_df['sample_id'].values:
            row = new_df[new_df['sample_id'] == sample].iloc[0]
            new_data[sample] = {
                gene: float(row[gene]) if gene in row else np.nan
                for gene in common_genes if gene in new_df.columns
            }
    
    # 값 비교
    differences = []
    correlations = []
    
    for sample in samples_to_check:
        if sample not in new_data or sample not in sample_indices:
            continue
        
        for gene in common_genes:
            if gene not in new_data[sample] or gene not in xena_data:
                continue
            
            new_val = new_data[sample][gene]
            xena_val = xena_data[gene][sample]
            
            if not (np.isnan(new_val) or np.isnan(xena_val)):
                diff = abs(new_val - xena_val)
                differences.append(diff)
    
    results = {
        'n_comparisons': len(differences),
        'mean_abs_diff': np.mean(differences) if differences else None,
        'median_abs_diff': np.median(differences) if differences else None,
        'max_abs_diff': np.max(differences) if differences else None,
    }
    
    if differences:
        logger.info(f"  Number of value comparisons: {results['n_comparisons']}")
        logger.info(f"  Mean absolute difference: {results['mean_abs_diff']:.6f}")
        logger.info(f"  Median absolute difference: {results['median_abs_diff']:.6f}")
        logger.info(f"  Max absolute difference: {results['max_abs_diff']:.6f}")
        
        # 값 범위 확인
        new_values = new_df[list(common_genes)[:100]].values.flatten()
        new_values = new_values[~np.isnan(new_values)]
        logger.info(f"  New dataset value range: [{np.min(new_values):.2f}, {np.max(new_values):.2f}]")
        logger.info(f"  New dataset value mean: {np.mean(new_values):.2f}")
    
    return results


def main():
    parser = argparse.ArgumentParser(
        description="Validate BRCA dataset compatibility"
    )
    parser.add_argument('--new_dataset', type=str, required=True,
                       help='Path to new BRCA-data-with-integer-labels.csv')
    parser.add_argument('--xena_expr', type=str, required=True,
                       help='Path to Xena TCGA-BRCA.star_fpkm-uq.tsv.gz')
    parser.add_argument('--gene_mapping', type=str, default=None,
                       help='Path to gene mapping file (gencode probemap, optional)')
    parser.add_argument('--output', type=str, default=None,
                       help='Output report file (optional)')
    
    args = parser.parse_args()
    
    # Gene mapping 로드
    gene_mapping = None
    if args.gene_mapping:
        gene_mapping = load_gene_mapping(args.gene_mapping)
    else:
        # 자동으로 찾기
        xena_dir = Path(args.xena_expr).parent
        probe_map = xena_dir / 'gencode.v36.annotation.gtf.gene.probemap'
        if probe_map.exists():
            logger.info(f"Auto-detected gene mapping file: {probe_map}")
            gene_mapping = load_gene_mapping(str(probe_map))
    
    # 로드
    new_df = load_new_dataset(args.new_dataset)
    xena_header, n_genes = load_xena_expression_header(args.xena_expr)
    xena_samples = xena_header[1:]  # 첫 번째는 gene_id
    xena_gene_ids = load_xena_gene_ids(args.xena_expr)
    
    # 비교
    sample_results = compare_samples(new_df, xena_samples)
    gene_results = compare_genes(new_df, xena_gene_ids, gene_mapping)
    
    # 공통 샘플과 유전자 찾기
    new_samples_set = set(new_df['sample_id'].values)
    xena_samples_set = set(xena_samples)
    common_samples = new_samples_set & xena_samples_set
    
    new_genes_set = set(new_df.columns[1:].tolist())
    xena_genes_set = set(xena_gene_ids)
    
    # Gene mapping을 사용하여 공통 유전자 찾기
    common_genes = new_genes_set & xena_genes_set  # 직접 매칭
    if gene_mapping:
        # Gene Symbol로 매칭
        xena_gene_symbols = {}
        for ensembl_id in xena_genes_set:
            base_id = ensembl_id.split('.')[0]
            if base_id in gene_mapping:
                symbol = gene_mapping[base_id]
                xena_gene_symbols[symbol] = ensembl_id
        
        mapped_common = new_genes_set & set(xena_gene_symbols.keys())
        common_genes = common_genes | mapped_common
        logger.info(f"  Common genes (including mapped): {len(common_genes)}")
    
    value_results = {}
    if common_samples and common_genes:
        value_results = compare_values(
            new_df, args.xena_expr, common_samples, common_genes, n_samples_check=10
        )
    
    # 종합 리포트
    logger.info("=" * 60)
    logger.info("SUMMARY")
    logger.info("=" * 60)
    logger.info(f"Sample compatibility:")
    logger.info(f"  Exact matches: {sample_results['exact_sample_matches']}/{sample_results['new_samples']} ({sample_results['exact_sample_matches']/sample_results['new_samples']*100:.1f}%)")
    logger.info(f"  Patient matches: {sample_results['patient_matches']}/{sample_results['new_patients']} ({sample_results['patient_matches']/sample_results['new_patients']*100:.1f}%)")
    logger.info(f"Gene compatibility:")
    if gene_results.get('mapped_matches', 0) > 0:
        logger.info(f"  Total matches: {gene_results['total_matches']}/{gene_results['new_genes']} ({gene_results['match_ratio']*100:.1f}%)")
        logger.info(f"    - Exact: {gene_results['exact_matches']}")
        logger.info(f"    - Mapped: {gene_results['mapped_matches']}")
    else:
        logger.info(f"  Exact matches: {gene_results['exact_matches']}/{gene_results['new_genes']} ({gene_results['match_ratio']*100:.1f}%)")
    
    if value_results:
        logger.info(f"Value compatibility:")
        logger.info(f"  Mean absolute difference: {value_results.get('mean_abs_diff', 'N/A')}")
    
    # 호환성 평가
    logger.info("=" * 60)
    logger.info("COMPATIBILITY ASSESSMENT")
    logger.info("=" * 60)
    
    # Patient ID 매칭 비율 사용 (샘플 바코드 형식이 다를 수 있음)
    patient_match_ratio = sample_results['patient_matches'] / sample_results['new_patients'] if sample_results['new_patients'] > 0 else 0
    gene_match_ratio = gene_results['match_ratio']
    
    logger.info(f"Patient match ratio: {patient_match_ratio:.1%}")
    logger.info(f"Gene match ratio: {gene_match_ratio:.1%}")
    
    if patient_match_ratio > 0.9 and gene_match_ratio > 0.9:
        logger.info("✓ HIGH COMPATIBILITY: Datasets are highly compatible")
        logger.info("  - All patients match (sample barcode format may differ)")
        logger.info("  - Nearly all genes match (via gene symbol mapping)")
    elif patient_match_ratio > 0.7 and gene_match_ratio > 0.7:
        logger.info("⚠ MODERATE COMPATIBILITY: Datasets are partially compatible")
        logger.info("  - Most patients and genes match")
    else:
        logger.info("✗ LOW COMPATIBILITY: Datasets have significant differences")
        logger.info("  - Some patients or genes may not match")
    
    # 출력 파일 저장
    if args.output:
        import json
        report = {
            'sample_comparison': sample_results,
            'gene_comparison': gene_results,
            'value_comparison': value_results,
        }
        with open(args.output, 'w') as f:
            json.dump(report, f, indent=2)
        logger.info(f"\nReport saved to: {args.output}")


if __name__ == '__main__':
    main()

