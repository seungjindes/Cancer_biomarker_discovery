#!/bin/bash
# 데이터 전처리 스크립트 (federated data 준비 전에 실행)

set -e

# 색상 출력 함수
echo_info() {
    echo -e "\033[0;32m[INFO]\033[0m $1"
}

echo_error() {
    echo -e "\033[0;31m[ERROR]\033[0m $1" >&2
}

# 기본 경로
DATA_DIR="${DATA_DIR:-data}"
XENA_DIR="${DATA_DIR}/xena"
TCIA_DIR="${DATA_DIR}/tcia"
OUTPUT_DIR="${OUTPUT_DIR:-data/processed}"

# 파일 경로
XENA_EXPR="${XENA_DIR}/TCGA-BRCA.star_fpkm-uq.tsv.gz"
XENA_CLIN="${XENA_DIR}/TCGA-BRCA.clinical.tsv.gz"
DICOM_ROOT="${TCIA_DIR}"

# 입력 파일 확인
echo_info "Checking input files..."

if [ ! -f "$XENA_EXPR" ]; then
    echo_error "Expression file not found: $XENA_EXPR"
    echo_error "Please download Xena data first"
    exit 1
fi

if [ ! -f "$XENA_CLIN" ]; then
    echo_error "Clinical file not found: $XENA_CLIN"
    echo_error "Please download Xena data first"
    exit 1
fi

if [ ! -d "$DICOM_ROOT" ]; then
    echo_error "DICOM root directory not found: $DICOM_ROOT"
    echo_error "Please download TCIA data first"
    exit 1
fi

echo_info "Input files found:"
echo_info "  Expression: $XENA_EXPR"
echo_info "  Clinical: $XENA_CLIN"
echo_info "  DICOM root: $DICOM_ROOT"
echo_info "  Output directory: $OUTPUT_DIR"

# 출력 디렉토리 생성
mkdir -p "$OUTPUT_DIR"

# 데이터 전처리 실행
echo_info "Running data preprocessing pipeline..."
echo_info "This may take a while..."

python3 scripts/build_tcga_brca_multimodal.py \
    --xena_expr "$XENA_EXPR" \
    --xena_clin "$XENA_CLIN" \
    --dicom_root "$DICOM_ROOT" \
    --out_dir "$OUTPUT_DIR"

if [ $? -eq 0 ]; then
    echo_info ""
    echo_info "Data preprocessing complete!"
    echo_info "Output files:"
    echo_info "  - $OUTPUT_DIR/cohort_index.parquet"
    echo_info "  - $OUTPUT_DIR/clinical_table.parquet"
    echo_info "  - $OUTPUT_DIR/expression_matrix.parquet"
    echo_info ""
    echo_info "Now you can run prepare_federated_data.sh:"
    echo_info "  bash scripts/prepare_federated_data.sh --data_dir $OUTPUT_DIR"
else
    echo_error "Data preprocessing failed!"
    exit 1
fi

