# TCIA 데이터 다운로드 스크립트 사용 가이드

## 포함된 파일

1. **check_download_status.sh** - 다운로드 진행 상황 확인
2. **download_tcia_data.py** - 다운로드 방법 안내
3. **download_tcia_full.py** - 전체 데이터셋 다운로드 (메인 스크립트)

## 사용 방법

### 1. 전체 데이터셋 다운로드 (권장)

```bash
# 기본 사용 (MR/MG 모달리티, 10개 병렬 워커)
python3 scripts/download_tcia_full.py \
    --output_dir ./data/tcia

# 병렬 워커 수 조정 (더 빠른 다운로드)
python3 scripts/download_tcia_full.py \
    --output_dir ./data/tcia \
    --max_workers 20

# 특정 모달리티만 다운로드
python3 scripts/download_tcia_full.py \
    --output_dir ./data/tcia \
    --modalities MR
```

**옵션:**
- `--collection`: 컬렉션 이름 (기본값: TCGA-BRCA)
- `--output_dir`: 출력 디렉토리 (기본값: ./data/tcia)
- `--max_workers`: 병렬 다운로드 워커 수 (기본값: 10)
- `--modalities`: 다운로드할 모달리티 (기본값: MR MG)

**주의사항:**
- 전체 데이터셋은 약 1TB 이상입니다
- 다운로드에는 수 시간 ~ 수 일이 걸릴 수 있습니다
- 충분한 디스크 공간을 확보하세요 (최소 1.5TB 권장)
- 안정적인 네트워크 연결이 필요합니다

### 2. 다운로드 진행 상황 확인

```bash
# 진행 상황 확인
bash scripts/check_download_status.sh

# 실시간 로그 확인
tail -f data/tcia_download.log

# 다운로드된 파일 수 확인
find data/tcia -name "*.dcm" -o -name "*.DCM" | wc -l

# 데이터 크기 확인
du -sh data/tcia
```

### 3. 백그라운드에서 다운로드 실행

```bash
# 백그라운드 실행
nohup python3 scripts/download_tcia_full.py \
    --output_dir ./data/tcia \
    --max_workers 10 \
    > data/tcia_download.log 2>&1 &

# 프로세스 ID 확인
echo $!

# 프로세스 확인
ps aux | grep download_tcia_full

# 로그 확인
tail -f data/tcia_download.log
```

### 4. 다운로드 방법 안내

```bash
# 다양한 다운로드 방법 안내
python3 scripts/download_tcia_data.py --method manual

# Docker 사용 (Docker 설치 시)
python3 scripts/download_tcia_data.py --method docker --output_dir ./data/tcia
```

## 전체 다운로드 워크플로우

```bash
# 1. 전체 데이터셋 다운로드 시작 (백그라운드)
nohup python3 scripts/download_tcia_full.py \
    --output_dir ./data/tcia \
    --max_workers 10 \
    > data/tcia_download.log 2>&1 &

# 2. 진행 상황 확인
bash scripts/check_download_status.sh

# 3. 다운로드 완료 후 멀티모달 데이터셋 생성
python3 scripts/build_tcga_brca_multimodal.py \
    --xena_expr ./data/xena/TCGA-BRCA.star_fpkm-uq.tsv.gz \
    --xena_clin ./data/xena/TCGA-BRCA.clinical.tsv.gz \
    --dicom_root ./data/tcia \
    --out_dir ./data/cohort
```

## 문제 해결

### 다운로드가 중단된 경우

다운로드 스크립트는 중단된 지점부터 재개할 수 있습니다. 같은 명령어로 다시 실행하면 이미 다운로드된 파일은 건너뜁니다.

```bash
# 중단된 다운로드 재개
python3 scripts/download_tcia_full.py \
    --output_dir ./data/tcia \
    --max_workers 10
```

### 디스크 공간 부족

```bash
# 디스크 공간 확인
df -h

# 필요한 공간: 최소 1.5TB
```

### 네트워크 문제

- 안정적인 인터넷 연결 확인
- 방화벽 설정 확인
- 프록시 설정이 필요한 경우 환경 변수 설정

## 예상 다운로드 시간

- 네트워크 속도에 따라 다름
- 일반적으로: 수 시간 ~ 수 일
- 빠른 네트워크 (100 Mbps): 약 1-2일
- 느린 네트워크 (10 Mbps): 약 1주일 이상

