#!/usr/bin/env python3
"""
TCGA-BRCA 멀티모달 데이터 파이프라인

3개 모달리티(Expression, Clinical, Imaging)를 매칭하여 환자 레벨 데이터셋을 생성합니다.
"""
import argparse
import gzip
import json
import logging
import sys
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

import numpy as np
import pandas as pd
import pydicom
from tqdm import tqdm

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('build_pipeline.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)


def extract_patient_id(sample_barcode: str) -> str:
    """TCGA 샘플 바코드에서 Patient ID 추출 (첫 12자)"""
    parts = sample_barcode.split("-")
    if len(parts) >= 3:
        return "-".join(parts[:3])
    return sample_barcode


def extract_sample_type_code(sample_barcode: str) -> str:
    """샘플 타입 코드 추출 (예: '01A' -> '01')"""
    parts = sample_barcode.split("-")
    if len(parts) >= 4:
        return parts[3][:2]
    return ""


def is_tumor_sample(sample_barcode: str) -> bool:
    """Tumor 샘플인지 확인 (01-09: tumor)"""
    code = extract_sample_type_code(sample_barcode)
    try:
        return 1 <= int(code) <= 9
    except ValueError:
        return False


def process_expression_data(
    expr_file: str,
    smoke_test: bool = False,
    max_patients: Optional[int] = None
) -> Tuple[Dict[str, str], List[str], int]:
    """
    Expression 데이터 처리: 01A 샘플만 필터링하고 환자 매핑 생성
    
    Returns:
        patient_to_sample: {patient_id: sample_barcode}
        selected_columns: 선택된 샘플 컬럼 리스트
        n_genes: 유전자 수
    """
    logger.info(f"[Expression] 파일 로딩: {expr_file}")
    
    # 헤더만 먼저 읽어서 컬럼 확인
    with gzip.open(expr_file, 'rt') if expr_file.endswith('.gz') else open(expr_file, 'rt') as f:
        header = f.readline().strip().split('\t')
    
    gene_id_col = header[0]
    sample_columns = header[1:]
    
    logger.info(f"[Expression] 총 샘플 수: {len(sample_columns)}")
    
    # 01A 샘플만 필터링
    tumor_01a_samples = [
        s for s in sample_columns
        if extract_sample_type_code(s) == "01"
    ]
    logger.info(f"[Expression] 01A 샘플 수: {len(tumor_01a_samples)}")
    
    # 환자 매핑 생성 (중복 시 lexicographically smallest 선택)
    patient_to_sample = {}
    patient_samples = defaultdict(list)
    
    for sample in tumor_01a_samples:
        patient_id = extract_patient_id(sample)
        patient_samples[patient_id].append(sample)
    
    for patient_id, samples in patient_samples.items():
        # 중복 시 가장 작은 바코드 선택
        patient_to_sample[patient_id] = min(samples)
        if len(samples) > 1:
            logger.debug(f"[Expression] 환자 {patient_id}: {len(samples)}개 샘플 중 {patient_to_sample[patient_id]} 선택")
    
    unique_patients = len(patient_to_sample)
    logger.info(f"[Expression] 고유 환자 수: {unique_patients}")
    
    # 선택된 샘플 컬럼 (gene_id + 선택된 샘플들)
    selected_columns = [gene_id_col] + [patient_to_sample[p] for p in sorted(patient_to_sample.keys())]
    
    # 유전자 수 확인 (첫 번째 컬럼 제외하고 행 수 계산)
    if smoke_test:
        # Smoke test: 첫 1000개 유전자만
        n_genes = 1000
    else:
        # 전체 유전자 수 계산
        with gzip.open(expr_file, 'rt') if expr_file.endswith('.gz') else open(expr_file, 'rt') as f:
            n_genes = sum(1 for _ in f) - 1  # 헤더 제외
    logger.info(f"[Expression] 유전자 수: {n_genes}")
    
    # max_patients 제한
    if max_patients and len(patient_to_sample) > max_patients:
        sorted_patients = sorted(patient_to_sample.keys())[:max_patients]
        patient_to_sample = {p: patient_to_sample[p] for p in sorted_patients}
        selected_columns = [gene_id_col] + [patient_to_sample[p] for p in sorted_patients]
        logger.info(f"[Expression] max_patients 제한: {len(patient_to_sample)}개 환자만 사용")
    
    return patient_to_sample, selected_columns, n_genes


def load_expression_matrix(
    expr_file: str,
    selected_columns: List[str],
    n_genes: int,
    smoke_test: bool = False
) -> pd.DataFrame:
    """
    Expression 행렬 로딩 (메모리 효율적)
    """
    logger.info(f"[Expression] 행렬 로딩 중... (선택된 샘플: {len(selected_columns)-1}개)")
    
    # Chunk로 읽기 (메모리 효율적)
    row_data = []  # 임시 리스트 (리스트들의 리스트)
    chunk_size = 10000
    n_expected_fields = len(selected_columns)
    skipped_lines = 0
    df_chunks = []  # DataFrame 리스트
    
    with gzip.open(expr_file, 'rt') if expr_file.endswith('.gz') else open(expr_file, 'rt') as f:
        # 헤더 읽기
        header = f.readline().strip().split('\t')
        col_indices = [header.index(col) for col in selected_columns]
        
        # 데이터 읽기
        for i, line in enumerate(tqdm(f, total=n_genes, desc="Loading expression")):
            if smoke_test and i >= 1000:
                break
            
            line = line.strip()
            if not line:  # 빈 줄 건너뛰기
                continue
            
            fields = line.split('\t')
            
            # 필드 수 검증
            if len(fields) < max(col_indices) + 1:
                skipped_lines += 1
                if skipped_lines <= 10:
                    logger.warning(f"[Expression] Line {i+2} has insufficient fields ({len(fields)} < {max(col_indices)+1}), skipping")
                continue
            
            try:
                selected_fields = [fields[idx] if idx < len(fields) else '' for idx in col_indices]
                # 필드 수 확인
                if len(selected_fields) != n_expected_fields:
                    skipped_lines += 1
                    if skipped_lines <= 10:
                        logger.warning(f"[Expression] Line {i+2} field count mismatch, skipping")
                    continue
                
                row_data.append(selected_fields)
            except (IndexError, ValueError) as e:
                skipped_lines += 1
                if skipped_lines <= 10:
                    logger.warning(f"[Expression] Line {i+2} parsing error: {e}, skipping")
                continue
            
            # Chunk가 충분히 쌓이면 DataFrame으로 변환
            if len(row_data) >= chunk_size:
                try:
                    df_chunk = pd.DataFrame(row_data, columns=selected_columns)
                    df_chunks.append(df_chunk)
                    row_data = []  # 리스트 초기화
                except ValueError as e:
                    logger.error(f"[Expression] Error creating DataFrame from chunk: {e}")
                    logger.error(f"[Expression] First few rows: {row_data[:3] if len(row_data) >= 3 else row_data}")
                    raise
    
    if skipped_lines > 10:
        logger.warning(f"[Expression] Total skipped lines: {skipped_lines}")
    
    # 마지막 chunk 처리
    if row_data:
        try:
            df_chunk = pd.DataFrame(row_data, columns=selected_columns)
            df_chunks.append(df_chunk)
        except ValueError as e:
            logger.error(f"[Expression] Error creating final DataFrame: {e}")
            logger.error(f"[Expression] Number of rows: {len(row_data)}")
            if row_data:
                logger.error(f"[Expression] First row length: {len(row_data[0])}")
                logger.error(f"[Expression] First row sample: {row_data[0][:5] if len(row_data[0]) >= 5 else row_data[0]}")
            raise
    
    # 모든 DataFrame 합치기
    if df_chunks:
        df = pd.concat(df_chunks, ignore_index=True)
    else:
        df = pd.DataFrame(columns=selected_columns)
    
    # 첫 번째 컬럼을 인덱스로 설정
    if len(df) > 0:
        df.set_index(selected_columns[0], inplace=True)
    
    logger.info(f"[Expression] 행렬 로딩 완료: {df.shape}")
    return df


def process_clinical_data(
    clinical_file: str,
    keep_non_tumor_fallback: bool = False,
    max_patients: Optional[int] = None
) -> Dict[str, str]:
    """
    Clinical 데이터 처리: 01A 우선 선택
    
    Returns:
        patient_to_row_id: {patient_id: sample_barcode}
    """
    logger.info(f"[Clinical] 파일 로딩: {clinical_file}")
    
    # Clinical 데이터 로드
    df_clin = pd.read_csv(clinical_file, sep='\t', low_memory=False)
    
    # 샘플 바코드 컬럼 찾기 (일반적으로 첫 번째 컬럼 또는 'sample' 컬럼)
    if 'sample' in df_clin.columns:
        sample_col = 'sample'
    elif 'Sample' in df_clin.columns:
        sample_col = 'Sample'
    else:
        # 첫 번째 컬럼 사용
        sample_col = df_clin.columns[0]
        logger.warning(f"[Clinical] 샘플 컬럼을 찾을 수 없어 첫 번째 컬럼 사용: {sample_col}")
    
    logger.info(f"[Clinical] 총 행 수: {len(df_clin)}")
    logger.info(f"[Clinical] 샘플 컬럼: {sample_col}")
    
    # 환자 ID 추출
    df_clin['patient_id'] = df_clin[sample_col].apply(extract_patient_id)
    df_clin['sample_type'] = df_clin[sample_col].apply(extract_sample_type_code)
    
    # 01A 우선 선택
    patient_to_row = {}
    
    for patient_id in df_clin['patient_id'].unique():
        patient_rows = df_clin[df_clin['patient_id'] == patient_id]
        
        # 01A 행 찾기
        tumor_01a = patient_rows[patient_rows['sample_type'] == '01']
        
        if len(tumor_01a) > 0:
            # 01A가 있으면 가장 작은 바코드 선택
            selected = tumor_01a.loc[tumor_01a[sample_col].idxmin()]
            patient_to_row[patient_id] = selected[sample_col]
        elif keep_non_tumor_fallback:
            # 01A가 없으면 다른 샘플 사용 (11A 등)
            selected = patient_rows.loc[patient_rows[sample_col].idxmin()]
            patient_to_row[patient_id] = selected[sample_col]
            logger.debug(f"[Clinical] 환자 {patient_id}: 01A 없음, {selected[sample_col]} 사용")
        else:
            # 01A가 없으면 제외
            logger.debug(f"[Clinical] 환자 {patient_id}: 01A 없음, 제외")
    
    logger.info(f"[Clinical] 선택된 환자 수: {len(patient_to_row)}")
    
    # max_patients 제한
    if max_patients and len(patient_to_row) > max_patients:
        sorted_patients = sorted(patient_to_row.keys())[:max_patients]
        patient_to_row = {p: patient_to_row[p] for p in sorted_patients}
        logger.info(f"[Clinical] max_patients 제한: {len(patient_to_row)}개 환자만 사용")
    
    return patient_to_row


def extract_dicom_metadata(
    dicom_root: str,
    smoke_test: bool = False,
    max_files: int = 1000
) -> Dict[str, Dict]:
    """
    DICOM 파일에서 메타데이터 추출
    
    Returns:
        patient_imaging: {
            patient_id: {
                'modalities': set(['MR', 'MG']),
                'n_studies': int,
                'n_series': int,
                'n_images': int,
                'series': {
                    study_uid: {
                        series_uid: {
                            'modality': str,
                            'n_images': int,
                            'example_paths': [str]
                        }
                    }
                }
            }
        }
    """
    logger.info(f"[Imaging] DICOM 메타데이터 추출 시작: {dicom_root}")
    
    dicom_path = Path(dicom_root)
    if not dicom_path.exists():
        logger.error(f"[Imaging] 디렉토리가 존재하지 않음: {dicom_root}")
        return {}
    
    patient_imaging = defaultdict(lambda: {
        'modalities': set(),
        'n_studies': 0,
        'n_series': 0,
        'n_images': 0,
        'series': defaultdict(lambda: defaultdict(lambda: {
            'modality': '',
            'n_images': 0,
            'example_paths': []
        }))
    })
    
    # DICOM 파일 찾기
    dicom_files = list(dicom_path.rglob("*.dcm")) + list(dicom_path.rglob("*.DCM"))
    
    if smoke_test:
        dicom_files = dicom_files[:max_files]
        logger.info(f"[Imaging] Smoke test: 처음 {len(dicom_files)}개 파일만 처리")
    
    logger.info(f"[Imaging] 발견된 DICOM 파일 수: {len(dicom_files)}")
    
    processed = 0
    errors = 0
    
    for dicom_file in tqdm(dicom_files, desc="Processing DICOM"):
        try:
            # 최소한의 태그만 읽기 (메모리 효율적)
            ds = pydicom.dcmread(str(dicom_file), stop_before_pixels=True)
            
            # PatientID 추출 및 정규화
            patient_id = str(ds.get('PatientID', '')).strip()
            if not patient_id or patient_id == '':
                continue
            
            # Modality 추출
            modality = str(ds.get('Modality', '')).strip()
            if modality not in ['MR', 'MG']:
                continue  # MR/MG만 사용
            
            # Study/Series UID 추출
            study_uid = str(ds.get('StudyInstanceUID', ''))
            series_uid = str(ds.get('SeriesInstanceUID', ''))
            
            if not study_uid or not series_uid:
                continue
            
            # 데이터 구조 업데이트
            patient_data = patient_imaging[patient_id]
            patient_data['modalities'].add(modality)
            
            series_data = patient_data['series'][study_uid][series_uid]
            series_data['modality'] = modality
            series_data['n_images'] += 1
            if len(series_data['example_paths']) < 3:  # 최대 3개 경로만 저장
                series_data['example_paths'].append(str(dicom_file))
            
            processed += 1
            
        except Exception as e:
            errors += 1
            if errors <= 10:  # 처음 10개 에러만 로깅
                logger.debug(f"[Imaging] 파일 처리 오류 ({dicom_file}): {e}")
            continue
    
    # 집계 계산
    for patient_id, data in patient_imaging.items():
        data['n_studies'] = len(data['series'])
        data['n_series'] = sum(len(series) for series in data['series'].values())
        data['n_images'] = sum(
            series_info['n_images']
            for study in data['series'].values()
            for series_info in study.values()
        )
        # set을 list로 변환 (JSON 직렬화를 위해)
        data['modalities'] = sorted(list(data['modalities']))
    
    logger.info(f"[Imaging] 처리 완료: {processed}개 파일, {errors}개 오류")
    logger.info(f"[Imaging] 발견된 환자 수: {len(patient_imaging)}")
    
    return dict(patient_imaging)


def create_cohort_index(
    expr_patients: Set[str],
    clin_patients: Set[str],
    img_patients: Set[str],
    patient_to_expr_sample: Dict[str, str],
    patient_to_clin_sample: Dict[str, str],
    patient_imaging: Dict[str, Dict]
) -> pd.DataFrame:
    """
    3개 모달리티의 교집합으로 cohort index 생성
    """
    # 교집합 계산
    intersection = expr_patients & clin_patients & img_patients
    
    logger.info(f"[Cohort] Expression 환자 수: {len(expr_patients)}")
    logger.info(f"[Cohort] Clinical 환자 수: {len(clin_patients)}")
    logger.info(f"[Cohort] Imaging 환자 수: {len(img_patients)}")
    logger.info(f"[Cohort] 교집합 환자 수: {len(intersection)}")
    
    # Cohort index 생성
    rows = []
    for patient_id in sorted(intersection):
        img_data = patient_imaging.get(patient_id, {})
        
        # Series 정보를 JSON 문자열로 변환
        series_dict = {}
        for study_uid, series_dict_in_study in img_data.get('series', {}).items():
            series_dict[study_uid] = {
                series_uid: {
                    'modality': info['modality'],
                    'n_images': info['n_images'],
                    'example_paths': info['example_paths'][:1]  # 첫 번째 경로만
                }
                for series_uid, info in series_dict_in_study.items()
            }
        
        row = {
            'patient_id': patient_id,
            'expr_sample_barcode': patient_to_expr_sample.get(patient_id, ''),
            'expr_n_genes': 0,  # 나중에 채움
            'clinical_row_id': patient_to_clin_sample.get(patient_id, ''),
            'has_imaging': True,
            'imaging_modalities': img_data.get('modalities', []),
            'n_studies': img_data.get('n_studies', 0),
            'n_series': img_data.get('n_series', 0),
            'n_images': img_data.get('n_images', 0),
            'dicom_series': json.dumps(series_dict) if series_dict else '{}'
        }
        rows.append(row)
    
    df_index = pd.DataFrame(rows)
    return df_index


def main():
    parser = argparse.ArgumentParser(
        description="TCGA-BRCA 멀티모달 데이터 파이프라인",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument(
        "--xena_expr",
        type=str,
        required=True,
        help="Xena expression 파일 경로 (TSV 또는 TSV.GZ)"
    )
    parser.add_argument(
        "--xena_clin",
        type=str,
        required=True,
        help="Xena clinical 파일 경로 (TSV 또는 TSV.GZ)"
    )
    parser.add_argument(
        "--dicom_root",
        type=str,
        required=True,
        help="TCIA DICOM 루트 디렉토리"
    )
    parser.add_argument(
        "--out_dir",
        type=str,
        required=True,
        help="출력 디렉토리"
    )
    parser.add_argument(
        "--keep_non_tumor_clinical_fallback",
        action="store_true",
        help="Clinical에서 01A가 없을 때 다른 샘플 사용 (기본값: False)"
    )
    parser.add_argument(
        "--no_expr_matrix",
        action="store_true",
        help="Expression 행렬 파일 생성 안 함"
    )
    parser.add_argument(
        "--max_patients",
        type=int,
        default=None,
        help="최대 환자 수 (디버깅용)"
    )
    parser.add_argument(
        "--smoke_test",
        action="store_true",
        help="Smoke test 모드 (소량 데이터만 처리)"
    )
    
    args = parser.parse_args()
    
    # 출력 디렉토리 생성
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    logs_dir = out_dir / "logs"
    logs_dir.mkdir(exist_ok=True)
    
    logger.info("=" * 80)
    logger.info("TCGA-BRCA 멀티모달 데이터 파이프라인 시작")
    logger.info("=" * 80)
    
    # 1. Expression 데이터 처리
    patient_to_expr_sample, selected_columns, n_genes = process_expression_data(
        args.xena_expr,
        smoke_test=args.smoke_test,
        max_patients=args.max_patients
    )
    expr_patients = set(patient_to_expr_sample.keys())
    
    # 2. Clinical 데이터 처리
    patient_to_clin_sample = process_clinical_data(
        args.xena_clin,
        keep_non_tumor_fallback=args.keep_non_tumor_clinical_fallback,
        max_patients=args.max_patients
    )
    clin_patients = set(patient_to_clin_sample.keys())
    
    # 3. DICOM 메타데이터 추출
    patient_imaging = extract_dicom_metadata(
        args.dicom_root,
        smoke_test=args.smoke_test
    )
    img_patients = set(patient_imaging.keys())
    
    # 4. 교집합 계산 및 Cohort Index 생성
    df_index = create_cohort_index(
        expr_patients,
        clin_patients,
        img_patients,
        patient_to_expr_sample,
        patient_to_clin_sample,
        patient_imaging
    )
    
    # Expression 행렬 로딩 (교집합 환자만)
    if not args.no_expr_matrix and len(df_index) > 0:
        logger.info("[Expression] 교집합 환자에 대한 행렬 로딩...")
        intersection_patients = set(df_index['patient_id'])
        intersection_samples = [
            patient_to_expr_sample[p] for p in sorted(intersection_patients)
        ]
        intersection_columns = [selected_columns[0]] + intersection_samples
        
        df_expr = load_expression_matrix(
            args.xena_expr,
            intersection_columns,
            n_genes,
            smoke_test=args.smoke_test
        )
        
        # 환자 ID를 인덱스로 변환
        df_expr.index.name = 'gene_id'
        df_expr = df_expr.T  # 전치: 행=환자, 열=유전자
        df_expr.index = [extract_patient_id(s) for s in df_expr.index]
        df_expr.index.name = 'patient_id'
        
        # expr_n_genes 업데이트
        df_index['expr_n_genes'] = len(df_expr.columns)
        
        # Expression 행렬 저장
        expr_output = out_dir / "expression_matrix.parquet"
        df_expr.to_parquet(expr_output, compression='snappy')
        logger.info(f"[Output] Expression 행렬 저장: {expr_output}")
    
    # 5. Clinical 테이블 생성 (교집합 환자만)
    df_clin_full = None
    if len(df_index) > 0:
        logger.info("[Clinical] 교집합 환자에 대한 Clinical 테이블 생성...")
        df_clin_full = pd.read_csv(args.xena_clin, sep='\t', low_memory=False)
        
        # 샘플 컬럼 찾기
        if 'sample' in df_clin_full.columns:
            sample_col = 'sample'
        elif 'Sample' in df_clin_full.columns:
            sample_col = 'Sample'
        else:
            sample_col = df_clin_full.columns[0]
        
        # 교집합 환자의 샘플 바코드
        intersection_samples = df_index['clinical_row_id'].tolist()
        df_clin_subset = df_clin_full[df_clin_full[sample_col].isin(intersection_samples)].copy()
        
        # 환자 ID 추가
        df_clin_subset['patient_id'] = df_clin_subset[sample_col].apply(extract_patient_id)
        df_clin_subset.set_index('patient_id', inplace=True)
        
        # Clinical 테이블 저장
        clin_output = out_dir / "clinical_table.parquet"
        df_clin_subset.to_parquet(clin_output, compression='snappy')
        logger.info(f"[Output] Clinical 테이블 저장: {clin_output}")
    
    # 6. Cohort Index 저장
    index_output = out_dir / "cohort_index.parquet"
    df_index.to_parquet(index_output, compression='snappy')
    logger.info(f"[Output] Cohort Index 저장: {index_output}")
    
    # CSV 버전도 저장 (읽기 쉽게)
    df_index.to_csv(out_dir / "cohort_index.csv", index=False)
    
    # 7. 통계 저장
    stats = {
        'expression': {
            'total_samples': len(selected_columns) - 1,
            'tumor_01a_samples': len(patient_to_expr_sample),
            'unique_patients': len(expr_patients),
            'n_genes': n_genes
        },
        'clinical': {
            'total_rows': len(df_clin_full) if df_clin_full is not None else 0,
            'unique_patients': len(clin_patients)
        },
        'imaging': {
            'unique_patients': len(img_patients),
            'total_dicom_files_processed': sum(d['n_images'] for d in patient_imaging.values())
        },
        'cohort': {
            'intersection_patients': len(df_index),
            'patients_with_all_modalities': len(df_index[df_index['has_imaging']])
        }
    }
    
    stats_file = logs_dir / "pipeline_stats.json"
    with open(stats_file, 'w') as f:
        json.dump(stats, f, indent=2)
    logger.info(f"[Output] 통계 저장: {stats_file}")
    
    logger.info("=" * 80)
    logger.info("파이프라인 완료!")
    logger.info(f"출력 디렉토리: {out_dir}")
    logger.info(f"최종 환자 수: {len(df_index)}")
    logger.info("=" * 80)


if __name__ == "__main__":
    main()

