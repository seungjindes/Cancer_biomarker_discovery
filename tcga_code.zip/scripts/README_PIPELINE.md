# TCGA-BRCA 멀티모달 데이터 파이프라인

이 파이프라인은 TCGA-BRCA 데이터셋의 3개 모달리티(Expression, Clinical, Imaging)를 매칭하여 환자 레벨 데이터셋을 생성합니다.

## 개요

### 입력 데이터

1. **Expression (Xena)**
   - 파일: `TCGA-BRCA.star_fpkm-uq.tsv.gz`
   - 형식: 행=Ensembl gene IDs, 열=sample barcodes (예: "TCGA-XX-XXXX-01A")
   - 값: log2(FPKM-UQ+1) float
   - 샘플 필터링: Primary Tumor "01A" 샘플만 사용

2. **Clinical (Xena)**
   - 파일: `TCGA-BRCA.clinical.tsv.gz` (또는 `TCGA-BRCA.GDC_phenotype.tsv.gz`)
   - 형식: 행=sample barcodes, 열=clinical fields
   - 샘플 선택: 01A 우선, 없으면 11A (설정 가능)

3. **Imaging (TCIA)**
   - 컬렉션: TCGA-BRCA
   - 형식: DICOM 파일 (MR/MG)
   - 모드: 로컬 DICOM 디렉토리 (권장)

### 매칭 규칙

- **Patient ID 정의**: 샘플 바코드의 첫 12자
  ```python
  patient_id = "-".join(sample_barcode.split("-")[0:3])  # 예: TCGA-BH-A0W3
  ```

- **Expression 필터링**:
  - 샘플 타입 코드 = 4번째 필드의 첫 2자리 (예: "01A" → "01")
  - `sample_type_code == "01"`인 샘플만 사용
  - 환자당 여러 01A 샘플이 있으면 lexicographically smallest 선택

- **Clinical 선택**:
  - 환자당 여러 행이 있으면 01A 우선
  - 여러 01A가 있으면 lexicographically smallest 선택
  - 01A가 없으면 제외 (또는 `--keep_non_tumor_clinical_fallback` 옵션으로 11A 사용)

- **TCIA 매칭**:
  - DICOM 파일의 `PatientID` 태그를 TCGA Patient ID와 매칭
  - PatientID 정규화 (공백 제거)
  - MR/MG 모달리티만 사용

### 출력 파일

출력 디렉토리에 다음 파일들이 생성됩니다:

1. **cohort_index.parquet** (및 .csv)
   - 환자별 인덱스 테이블
   - 컬럼:
     - `patient_id`: TCGA Patient ID
     - `expr_sample_barcode`: 선택된 Expression 샘플 바코드
     - `expr_n_genes`: 유전자 수
     - `clinical_row_id`: 선택된 Clinical 샘플 바코드
     - `has_imaging`: 이미지 데이터 존재 여부
     - `imaging_modalities`: 이미지 모달리티 리스트
     - `n_studies`, `n_series`, `n_images`: DICOM 통계
     - `dicom_series`: JSON 문자열 (StudyInstanceUID → SeriesInstanceUID → 메타데이터)

2. **expression_matrix.parquet** (선택사항)
   - 행: patient_id
   - 열: gene_id
   - 값: expression 값 (선택된 01A 샘플)

3. **clinical_table.parquet**
   - 행: patient_id
   - 열: clinical fields (약 85개 컬럼)
   - 교집합 환자만 포함

4. **logs/pipeline_stats.json**
   - 각 단계별 통계 정보

## 설치

필요한 패키지:

```bash
pip install pandas pyarrow pydicom tqdm numpy
```

또는 requirements.txt 사용:

```bash
pip install -r requirements.txt
```

## 사용 방법

### 1. 데이터 다운로드

#### Expression 및 Clinical 데이터

```bash
python scripts/download_xena_data.py --output_dir ./data/xena
```

이 스크립트는 다음 파일들을 다운로드합니다:
- `TCGA-BRCA.star_fpkm-uq.tsv.gz`
- `TCGA-BRCA.clinical.tsv.gz` (또는 `TCGA-BRCA.GDC_phenotype.tsv.gz`)
- `gencode.v36.annotation.gtf.gene.probemap`

#### TCIA 이미지 데이터

TCIA 데이터는 수동으로 다운로드하거나 NBIA Data Retriever를 사용합니다:

```bash
# 수동 다운로드 안내
python scripts/download_tcia_data.py --method manual

# 또는 Docker 사용
python scripts/download_tcia_data.py --method docker --output_dir ./data/tcia
```

### 2. 파이프라인 실행

기본 실행:

```bash
python scripts/build_tcga_brca_multimodal.py \
    --xena_expr ./data/xena/TCGA-BRCA.star_fpkm-uq.tsv.gz \
    --xena_clin ./data/xena/TCGA-BRCA.clinical.tsv.gz \
    --dicom_root ./data/tcia \
    --out_dir ./data/cohort
```

옵션:

```bash
# Clinical에서 01A가 없을 때 11A 사용
--keep_non_tumor_clinical_fallback

# Expression 행렬 파일 생성 안 함
--no_expr_matrix

# 최대 환자 수 제한 (디버깅용)
--max_patients 100

# Smoke test 모드 (소량 데이터만 처리)
--smoke_test
```

### 3. Smoke Test

빠른 검증을 위한 smoke test:

```bash
python scripts/build_tcga_brca_multimodal.py \
    --xena_expr ./data/xena/TCGA-BRCA.star_fpkm-uq.tsv.gz \
    --xena_clin ./data/xena/TCGA-BRCA.clinical.tsv.gz \
    --dicom_root ./data/tcia \
    --out_dir ./data/cohort_test \
    --smoke_test \
    --max_patients 50
```

## 처리 단계별 통계

파이프라인은 각 단계에서 다음 통계를 로깅합니다:

1. **Expression**:
   - 총 샘플 수
   - 01A 샘플 수 (필터링 후)
   - 고유 환자 수
   - 유전자 수

2. **Clinical**:
   - 총 행 수
   - 고유 환자 수
   - 선택된 환자 수

3. **Imaging**:
   - 발견된 DICOM 파일 수
   - 처리된 파일 수
   - 오류 수
   - 고유 환자 수

4. **Cohort**:
   - Expression 환자 수
   - Clinical 환자 수
   - Imaging 환자 수
   - **교집합 환자 수** (최종)

## 메모리 효율성

- Expression 행렬은 chunk 단위로 읽어 메모리 사용을 최소화합니다
- DICOM 파일은 픽셀 데이터를 읽지 않고 메타데이터만 추출합니다
- 필요한 샘플 컬럼만 선택하여 로딩합니다

## 문제 해결

### DICOM 파일을 찾을 수 없음

- `--dicom_root` 경로가 올바른지 확인
- DICOM 파일이 `.dcm` 또는 `.DCM` 확장자를 가지고 있는지 확인
- 하위 디렉토리까지 재귀적으로 탐색합니다

### Patient ID 매칭 실패

- DICOM 파일의 `PatientID` 태그가 TCGA 형식인지 확인
- 공백이나 특수 문자가 있는지 확인 (자동 정규화됨)

### 메모리 부족

- `--no_expr_matrix` 옵션으로 Expression 행렬 저장 건너뛰기
- `--max_patients` 옵션으로 환자 수 제한
- `--smoke_test` 옵션으로 소량 데이터만 처리

## 출력 예시

```
cohort/
├── cohort_index.parquet
├── cohort_index.csv
├── expression_matrix.parquet
├── clinical_table.parquet
└── logs/
    ├── pipeline_stats.json
    └── build_pipeline.log
```

## 참고 자료

- [Xena Browser](https://xenabrowser.net/)
- [TCIA](https://www.cancerimagingarchive.net/)
- [TCGA Data Portal](https://portal.gdc.cancer.gov/)


