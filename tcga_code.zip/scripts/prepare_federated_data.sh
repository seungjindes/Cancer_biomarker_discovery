#!/bin/bash
# 3가지 모달리티 데이터셋 전처리 및 디리클레 분포를 통한 클라이언트 데이터 분할 스크립트

set -e

# 기본 설정 (환경 변수로 오버라이드 가능)
DATA_DIR="${DATA_DIR:-data/processed}"
OUTPUT_DIR="${OUTPUT_DIR:-data/federated_splits}"
N_CLIENTS="${N_CLIENTS:-3}"
ALPHA="${ALPHA:-1.0}"
VARIANT="${VARIANT:-v1_imaging}"
SEED="${SEED:-42}"
TRAIN_RATIO="${TRAIN_RATIO:-0.7}"
VAL_RATIO="${VAL_RATIO:-0.15}"
TEST_RATIO="${TEST_RATIO:-0.15}"

# 색상 출력 함수
echo_info() {
    echo -e "\033[0;32m[INFO]\033[0m $1"
}

echo_error() {
    echo -e "\033[0;31m[ERROR]\033[0m $1" >&2
}

echo_warn() {
    echo -e "\033[0;33m[WARN]\033[0m $1"
}

# 스크립트 디렉토리
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TCGA_CODE_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

# 인자 파싱
while [[ $# -gt 0 ]]; do
    case $1 in
        --data_dir)
            DATA_DIR="$2"
            shift 2
            ;;
        --output_dir)
            OUTPUT_DIR="$2"
            shift 2
            ;;
        --n_clients)
            N_CLIENTS="$2"
            shift 2
            ;;
        --alpha)
            ALPHA="$2"
            shift 2
            ;;
        --variant)
            VARIANT="$2"
            shift 2
            ;;
        --seed)
            SEED="$2"
            shift 2
            ;;
        --train_ratio)
            TRAIN_RATIO="$2"
            shift 2
            ;;
        --val_ratio)
            VAL_RATIO="$2"
            shift 2
            ;;
        --test_ratio)
            TEST_RATIO="$2"
            shift 2
            ;;
        --pam50_file)
            PAM50_FILE="$2"
            shift 2
            ;;
        --brca_labels_file)
            BRCA_LABELS_FILE="$2"
            shift 2
            ;;
        --help)
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Options:"
            echo "  --data_dir DIR          Data directory (default: data/processed)"
            echo "  --output_dir DIR         Output directory for splits (default: data/federated_splits)"
            echo "  --n_clients N            Number of clients (default: 5)"
            echo "  --alpha FLOAT            Dirichlet concentration parameter (default: 0.3)"
            echo "                          Lower values = more non-IID distribution"
            echo "                          Recommended: 0.1 (very non-IID), 0.3 (moderate), 1.0 (IID-like)"
            echo "  --variant VARIANT        Variant: v1_imaging or v2_no_imaging (default: v1_imaging)"
            echo "  --seed INT               Random seed (default: 42)"
            echo "  --train_ratio FLOAT      Train split ratio (default: 0.7)"
            echo "  --val_ratio FLOAT         Validation split ratio (default: 0.15)"
            echo "  --test_ratio FLOAT        Test split ratio (default: 0.15)"
            echo "                          Note: train_ratio + val_ratio + test_ratio = 1.0"
            echo "  --pam50_file FILE        Path to PAM50 labels file (default: data/pam50.txt)"
            echo "  --brca_labels_file FILE  Path to BRCA-data-with-integer-labels.csv (default: data/BRCA-data-with-integer-labels.csv)"
            echo "                          Highest priority for subtype labels"
            echo ""
            echo "Environment variables (can override defaults):"
            echo "  DATA_DIR, OUTPUT_DIR, N_CLIENTS, ALPHA, VARIANT, SEED, TRAIN_RATIO, VAL_RATIO, TEST_RATIO"
            echo ""
            echo "Examples:"
            echo "  # Basic usage with defaults"
            echo "  $0"
            echo ""
            echo "  # Custom number of clients and alpha"
            echo "  $0 --n_clients 10 --alpha 0.1"
            echo ""
            echo "  # V2 variant (no imaging)"
            echo "  $0 --variant v2_no_imaging --n_clients 8 --alpha 0.5"
            echo ""
            exit 0
            ;;
        *)
            echo_error "Unknown option: $1"
            echo "Use --help for usage information"
            exit 1
            ;;
    esac
done

# 입력 파일 경로
COHORT_INDEX="${DATA_DIR}/cohort_index.parquet"
CLINICAL_TABLE="${DATA_DIR}/clinical_table.parquet"
GENE_SET_TABLE="${DATA_DIR}/expression_matrix.parquet"

# 레이블 파일 경로 (여러 위치에서 찾기)
# 1. 환경변수로 지정된 경로
# 2. data/ 디렉토리 (DATA_DIR의 부모 또는 data/)
# 3. DATA_DIR 내부
if [ -z "$PAM50_FILE" ]; then
    if [ -f "${DATA_DIR}/../pam50.txt" ]; then
        PAM50_FILE="${DATA_DIR}/../pam50.txt"
    elif [ -f "${DATA_DIR}/pam50.txt" ]; then
        PAM50_FILE="${DATA_DIR}/pam50.txt"
    elif [ -f "data/pam50.txt" ]; then
        PAM50_FILE="data/pam50.txt"
    fi
fi

if [ -z "$BRCA_LABELS_FILE" ]; then
    if [ -f "${DATA_DIR}/../BRCA-data-with-integer-labels.csv" ]; then
        BRCA_LABELS_FILE="${DATA_DIR}/../BRCA-data-with-integer-labels.csv"
    elif [ -f "${DATA_DIR}/BRCA-data-with-integer-labels.csv" ]; then
        BRCA_LABELS_FILE="${DATA_DIR}/BRCA-data-with-integer-labels.csv"
    elif [ -f "data/BRCA-data-with-integer-labels.csv" ]; then
        BRCA_LABELS_FILE="data/BRCA-data-with-integer-labels.csv"
    fi
fi

# 입력 파일 확인
echo_info "Checking input files..."
MISSING_FILES=0

if [ ! -f "$COHORT_INDEX" ]; then
    echo_error "Cohort index file not found: $COHORT_INDEX"
    MISSING_FILES=1
fi

if [ ! -f "$CLINICAL_TABLE" ]; then
    echo_error "Clinical table file not found: $CLINICAL_TABLE"
    MISSING_FILES=1
fi

if [ ! -f "$GENE_SET_TABLE" ]; then
    echo_warn "Gene set table not found at $GENE_SET_TABLE, trying alternative..."
    GENE_SET_TABLE="${DATA_DIR}/gene_set_table.parquet"
    if [ ! -f "$GENE_SET_TABLE" ]; then
        echo_error "Gene set table file not found"
        MISSING_FILES=1
    fi
fi

if [ $MISSING_FILES -eq 1 ]; then
    echo_error ""
    echo_error "Required data files are missing!"
    echo_error ""
    echo_error "You need to run the data preprocessing pipeline first."
    echo_error ""
    echo_error "Option 1: Use the helper script (recommended)"
    echo_error "  bash scripts/prepare_data_first.sh"
    echo_error ""
    echo_error "Option 2: Run manually"
    echo_error "  python3 scripts/build_tcga_brca_multimodal.py \\"
    echo_error "      --xena_expr data/xena/TCGA-BRCA.star_fpkm-uq.tsv.gz \\"
    echo_error "      --xena_clin data/xena/TCGA-BRCA.clinical.tsv.gz \\"
    echo_error "      --dicom_root data/tcia \\"
    echo_error "      --out_dir ${DATA_DIR}"
    echo_error ""
    echo_error "Or check if the data files exist in a different location and specify with --data_dir"
    echo_error ""
    exit 1
fi

echo_info "Input files found:"
echo_info "  Cohort index: $COHORT_INDEX"
echo_info "  Clinical table: $CLINICAL_TABLE"
echo_info "  Gene set table: $GENE_SET_TABLE"

# 출력 디렉토리 생성
mkdir -p "$OUTPUT_DIR"

# 설정 출력
echo_info "Configuration:"
echo_info "  Variant: $VARIANT"
echo_info "  Number of clients: $N_CLIENTS"
echo_info "  Dirichlet alpha: $ALPHA"
echo_info "  Random seed: $SEED"
    echo_info "  Train ratio: $TRAIN_RATIO"
    echo_info "  Val ratio: $VAL_RATIO"
    echo_info "  Test ratio: $TEST_RATIO"
echo_info "  Output directory: $OUTPUT_DIR"

# Python 스크립트 실행
echo_info "Running data preparation and client splitting..."

# Build command
CMD="python3 $SCRIPT_DIR/prepare_multimodal_dirichlet_splits.py \
    --cohort_index $COHORT_INDEX \
    --clinical_table $CLINICAL_TABLE \
    --gene_set_table $GENE_SET_TABLE \
    --output_dir $OUTPUT_DIR \
    --n_clients $N_CLIENTS \
    --alpha $ALPHA \
    --variant $VARIANT \
    --seed $SEED \
    --train_ratio $TRAIN_RATIO \
    --val_ratio $VAL_RATIO \
    --test_ratio $TEST_RATIO"

# Add BRCA labels file if it exists (highest priority)
if [ -f "$BRCA_LABELS_FILE" ]; then
    echo_info "BRCA labels file found: $BRCA_LABELS_FILE"
    CMD="$CMD --brca_labels_file $BRCA_LABELS_FILE"
else
    echo_warn "BRCA labels file not found: $BRCA_LABELS_FILE"
fi

# Add PAM50 file if it exists (fallback)
if [ -f "$PAM50_FILE" ]; then
    echo_info "PAM50 file found: $PAM50_FILE"
    CMD="$CMD --pam50_file $PAM50_FILE"
else
    echo_warn "PAM50 file not found: $PAM50_FILE (will use as fallback if BRCA labels not available)"
fi

# Execute command
eval $CMD

if [ $? -eq 0 ]; then
    echo_info "Data preparation complete!"
    echo_info "Output directory: $OUTPUT_DIR"
    echo_info ""
    echo_info "Output structure:"
    echo_info "  $OUTPUT_DIR/"
    echo_info "    ├── summary.json              # 전체 통계"
    echo_info "    └── site-{1..N}/              # 각 클라이언트 디렉토리"
    echo_info "        ├── cohort_index.parquet"
    echo_info "        ├── clinical_table.parquet"
    echo_info "        ├── gene_set_table.parquet"
    echo_info "        ├── train_patients.csv"
    echo_info "        ├── val_patients.csv"
    echo_info "        ├── test_patients.csv"
    echo_info "    └── patient_to_site_mapping.csv (with split info)"
    echo_info ""
    echo_info "To view summary:"
    echo_info "  cat $OUTPUT_DIR/summary.json | python -m json.tool"
else
    echo_error "Data preparation failed!"
    exit 1
fi

