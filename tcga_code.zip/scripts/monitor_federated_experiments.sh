#!/bin/bash
# Monitor federated learning experiments with formatted output

WORKSPACE=${1:-outputs/nvflare_workspace}
EXPERIMENT_NAME=${2:-"federated_experiment"}

echo "=== Federated Learning Experiment Monitor ==="
echo "Experiment: $EXPERIMENT_NAME"
echo "Workspace: $WORKSPACE"
echo ""

# Create log directory for this experiment
LOG_DIR="outputs/experiment_logs/${EXPERIMENT_NAME}"
mkdir -p "$LOG_DIR"

# Function to extract and format metrics
extract_metrics() {
    local site_id=$1
    local log_file="${WORKSPACE}/site-${site_id}/log.txt"
    
    if [ ! -f "$log_file" ]; then
        return
    fi
    
    echo "--- Site ${site_id} Metrics ---"
    
    # Extract round information
    tail -200 "$log_file" | grep -E "Round.*Complete|Training Metrics|Validation Metrics|Test Metrics" | tail -30
    
    echo ""
}

# Monitor all sites
for site_id in 1 2 3; do
    extract_metrics $site_id
done

# Save aggregated metrics
echo "=== Aggregated Metrics ===" > "${LOG_DIR}/metrics_$(date +%Y%m%d_%H%M%S).txt"
for site_id in 1 2 3; do
    extract_metrics $site_id >> "${LOG_DIR}/metrics_$(date +%Y%m%d_%H%M%S).txt"
done

echo "Metrics saved to: ${LOG_DIR}/"


