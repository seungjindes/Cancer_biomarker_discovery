#!/bin/bash
# Run federated learning with enhanced logging

set -e

# Configuration
EXPERIMENT_NAME=${EXPERIMENT_NAME:-"fed_$(date +%Y%m%d_%H%M%S)"}
N_CLIENTS=${N_CLIENTS:-3}
NUM_ROUNDS=${NUM_ROUNDS:-10}
SPLIT_DIR=${SPLIT_DIR:-data/federated_splits_backup_test}
DATA_ROOT=${DATA_ROOT:-data/processed}
JOB_ROOT=${JOB_ROOT:-outputs/nvflare_jobs}
WORKSPACE=${WORKSPACE:-outputs/nvflare_workspace}

# Create experiment log directory
LOG_DIR="outputs/experiment_logs/${EXPERIMENT_NAME}"
mkdir -p "$LOG_DIR"

echo "=== Federated Learning Experiment ==="
echo "Experiment Name: $EXPERIMENT_NAME"
echo "Number of Clients: $N_CLIENTS"
echo "Number of Rounds: $NUM_ROUNDS"
echo "Split Directory: $SPLIT_DIR"
echo "Log Directory: $LOG_DIR"
echo ""

# Save experiment configuration
cat > "${LOG_DIR}/experiment_config.txt" << EOF
Experiment: $EXPERIMENT_NAME
Date: $(date)
Number of Clients: $N_CLIENTS
Number of Rounds: $NUM_ROUNDS
Split Directory: $SPLIT_DIR
Data Root: $DATA_ROOT
Workspace: $WORKSPACE
EOF

# Run federated learning
echo "Starting federated learning..."
bash scripts/run_federated_training.sh \
    > "${LOG_DIR}/federated_training.log" 2>&1

# Extract and save metrics
echo ""
echo "Extracting metrics..."
bash scripts/monitor_federated_experiments.sh "$WORKSPACE" "$EXPERIMENT_NAME"

# Create summary
echo "=== Experiment Summary ===" > "${LOG_DIR}/summary.txt"
echo "Experiment: $EXPERIMENT_NAME" >> "${LOG_DIR}/summary.txt"
echo "Start Time: $(date)" >> "${LOG_DIR}/summary.txt"
echo "" >> "${LOG_DIR}/summary.txt"

# Extract final metrics from each site
for site_id in $(seq 1 $N_CLIENTS); do
    site_log="${WORKSPACE}/site-${site_id}/log.txt"
    if [ -f "$site_log" ]; then
        echo "--- Site ${site_id} Final Metrics ---" >> "${LOG_DIR}/summary.txt"
        tail -50 "$site_log" | grep -E "Round.*Complete|Validation Metrics|Test Metrics" | tail -10 >> "${LOG_DIR}/summary.txt"
        echo "" >> "${LOG_DIR}/summary.txt"
    fi
done

echo "Experiment complete!"
echo "Results saved to: $LOG_DIR"
echo ""
echo "To view logs:"
echo "  tail -f ${LOG_DIR}/federated_training.log"
echo "  cat ${LOG_DIR}/summary.txt"


