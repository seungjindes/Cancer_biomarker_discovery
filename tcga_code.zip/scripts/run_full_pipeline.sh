#!/bin/bash
# TCGA-BRCA 전체 파이프라인 실행 스크립트
# 데이터 다운로드부터 NVFlare 학습까지 전체 과정을 실행합니다.

set -e  # 오류 발생 시 중단

# 기본 경로 설정
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TCGA_CODE_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
DATA_DIR="${DATA_DIR:-$TCGA_CODE_DIR/data}"

# 색상 출력
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

echo_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

echo_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 1. Xena 데이터 다운로드
echo_info "1단계: Xena TCGA-BRCA gene expression 데이터 다운로드"
python "$SCRIPT_DIR/download_xena_data.py" \
    --output_dir "$DATA_DIR/xena" \
    --force

# 2. TCIA 이미지 데이터 다운로드 안내
echo_warn "2단계: TCIA TCGA-BRCA 이미지 데이터 다운로드"
echo_warn "TCIA 데이터는 수동 다운로드 또는 NBIA Data Retriever가 필요합니다."
echo_warn "다운로드 방법:"
echo_warn "  python $SCRIPT_DIR/download_tcia_data.py --method manual"
echo_warn ""
read -p "TCIA 데이터를 이미 다운로드하셨나요? (y/n): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo_warn "TCIA 데이터 다운로드를 먼저 완료해주세요."
    echo_warn "다운로드 후 이 스크립트를 다시 실행하세요."
    exit 1
fi

TCIA_DIR="${TCIA_DIR:-$DATA_DIR/tcia}"
if [ ! -d "$TCIA_DIR" ]; then
    echo_error "TCIA 디렉토리를 찾을 수 없습니다: $TCIA_DIR"
    echo_error "TCIA_DIR 환경 변수를 설정하거나 데이터를 $TCIA_DIR에 배치하세요."
    exit 1
fi

# 3. 데이터 전처리 및 pairs CSV 생성
echo_info "3단계: 데이터 전처리 및 pairs CSV 생성"
XENA_FILE="$DATA_DIR/xena/TCGA-BRCA.star_fpkm-uq.tsv"
GENE_MAPPING_FILE="$DATA_DIR/xena/gencode.v36.annotation.gtf.gene.probemap"
OUTPUT_CSV="$DATA_DIR/pairs.csv"
OUTPUT_OMICS_DIR="$DATA_DIR/omics"

if [ ! -f "$XENA_FILE" ]; then
    echo_error "Xena 데이터 파일을 찾을 수 없습니다: $XENA_FILE"
    exit 1
fi

python "$SCRIPT_DIR/preprocess_tcga_brca.py" \
    --xena_file "$XENA_FILE" \
    --tcia_dir "$TCIA_DIR" \
    --output_csv "$OUTPUT_CSV" \
    --output_omics_dir "$OUTPUT_OMICS_DIR" \
    --gene_mapping_file "$GENE_MAPPING_FILE" \
    --filter_tumor_only \
    --omics_method mean \
    --min_images 1

# 4. 데이터 분할
echo_info "4단계: 데이터 분할 (Dirichlet 분할)"
N_CLIENTS="${N_CLIENTS:-3}"
SPLIT_DIR="$DATA_DIR/splits"

python "$SCRIPT_DIR/prepare_dirichlet_splits.py" \
    --pairs_csv "$OUTPUT_CSV" \
    --out_dir "$SPLIT_DIR" \
    --n_clients "$N_CLIENTS" \
    --alpha 0.3 \
    --seed 42

# 5. Omics 차원 확인
echo_info "5단계: Omics 차원 확인"
if [ -f "$OUTPUT_OMICS_DIR"/*.npy ]; then
    FIRST_OMICS_FILE=$(ls "$OUTPUT_OMICS_DIR"/*.npy | head -n 1)
    OMICS_DIM=$(python -c "import numpy as np; print(np.load('$FIRST_OMICS_FILE').shape[0])")
    echo_info "Omics 차원: $OMICS_DIM"
else
    echo_error "Omics 벡터 파일을 찾을 수 없습니다."
    exit 1
fi

# 6. NVFlare Job 실행
echo_info "6단계: NVFlare Job 실행"
JOB_ROOT="${JOB_ROOT:-/tmp/nvflare/jobs/job_config}"
WORKSPACE="${WORKSPACE:-/tmp/nvflare/jobs/workdir}"
NUM_ROUNDS="${NUM_ROUNDS:-10}"

# data_root는 각 클라이언트에서 접근 가능한 경로여야 합니다
# 시뮬레이터를 사용하는 경우 절대 경로를 사용합니다
DATA_ROOT=$(cd "$DATA_DIR" && pwd)

python "$TCGA_CODE_DIR/job.py" \
    --job_root "$JOB_ROOT" \
    --workspace "$WORKSPACE" \
    --n_clients "$N_CLIENTS" \
    --num_rounds "$NUM_ROUNDS" \
    --split_dir "$SPLIT_DIR" \
    --data_root "$DATA_ROOT" \
    --omics_dim "$OMICS_DIM"

echo_info "전체 파이프라인 완료!"

