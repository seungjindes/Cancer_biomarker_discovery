#!/bin/bash
# Evaluation script for V1 or V2 variant

set -e

# Configuration
VARIANT="${1:-v1_imaging}"  # Default to v1_imaging
CONFIG="configs/${VARIANT}.yaml"
CHECKPOINT="${2:-outputs/checkpoints/${VARIANT}/fold_0/best.pt}"  # Default checkpoint
DATA_DIR="data/processed"  # Update with your data directory
OUT_DIR="outputs"
FOLD=0
N_FOLDS=5
SEED=42
PAM50_FILE="${PAM50_FILE:-data/pam50.txt}"  # PAM50 labels file (optional)
BRCA_LABELS_FILE="${BRCA_LABELS_FILE:-data/BRCA-data-with-integer-labels.csv}"  # BRCA labels file (highest priority)

# Validate variant
if [[ ! "$VARIANT" =~ ^(v1_imaging|v2_no_imaging)$ ]]; then
    echo "Error: VARIANT must be 'v1_imaging' or 'v2_no_imaging'"
    exit 1
fi

# Evaluate
echo "Evaluating ${VARIANT} with checkpoint ${CHECKPOINT}..."
python3 src/eval.py \
    --variant ${VARIANT} \
    --config ${CONFIG} \
    --checkpoint ${CHECKPOINT} \
    --data_dir ${DATA_DIR} \
    --out_dir ${OUT_DIR} \
    --fold ${FOLD} \
    --n_folds ${N_FOLDS} \
    --seed ${SEED} \
    --pam50_file ${PAM50_FILE} \
    --brca_labels_file ${BRCA_LABELS_FILE}

echo "Evaluation complete!"

