#!/usr/bin/env python3
"""
3가지 모달리티 데이터셋 전처리 및 디리클레 분포를 통한 클라이언트 데이터 분할

입력:
- cohort_index.parquet
- clinical_table.parquet
- expression_matrix.parquet (또는 gene_set_table.parquet)
- dicom_root (V1만 필요)

출력:
- 각 클라이언트별 데이터 분할 파일
- 통계 및 요약 정보
"""
import argparse
import json
import logging
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def load_multimodal_data(
    cohort_index_path: str,
    clinical_table_path: str,
    gene_set_path: str,
    variant: str = 'v1_imaging'
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """3가지 모달리티 데이터 로드."""
    logger.info("Loading multimodal data...")
    
    # Load cohort index
    cohort_index = pd.read_parquet(cohort_index_path) if cohort_index_path.endswith('.parquet') else pd.read_csv(cohort_index_path)
    logger.info(f"Loaded cohort_index: {len(cohort_index)} patients")
    
    # Load clinical table
    clinical_table = pd.read_parquet(clinical_table_path) if clinical_table_path.endswith('.parquet') else pd.read_csv(clinical_table_path)
    if 'patient_id' in clinical_table.columns and 'patient_id' not in clinical_table.index.names:
        clinical_table = clinical_table.set_index('patient_id')
    logger.info(f"Loaded clinical_table: {len(clinical_table)} patients, {len(clinical_table.columns)} features")
    
    # Load gene set table
    gene_set_table = pd.read_parquet(gene_set_path) if gene_set_path.endswith('.parquet') else pd.read_csv(gene_set_path)
    if 'patient_id' in gene_set_table.columns and 'patient_id' not in gene_set_table.index.names:
        gene_set_table = gene_set_table.set_index('patient_id')
    logger.info(f"Loaded gene_set_table: {len(gene_set_table)} patients, {len(gene_set_table.columns)} gene sets")
    
    # Filter by variant
    if variant == 'v1_imaging':
        # V1: imaging-present patients
        has_imaging = cohort_index.get('has_imaging', False)
        if isinstance(has_imaging, pd.Series):
            cohort_index = cohort_index[cohort_index['has_imaging'] == True]
        else:
            # Check imaging_modalities or dicom_series
            has_modalities = cohort_index.get('imaging_modalities', pd.Series([], dtype=object)).apply(
                lambda x: isinstance(x, (list, str)) and (('MR' in str(x)) or ('MG' in str(x))) if pd.notna(x) else False
            )
            has_dicom = cohort_index.get('dicom_series', pd.Series([], dtype=object)).apply(
                lambda x: pd.notna(x) and x != '{}' and x != '' if isinstance(x, str) else False
            )
            cohort_index = cohort_index[has_modalities | has_dicom]
        logger.info(f"V1 cohort (imaging-present): {len(cohort_index)} patients")
    elif variant == 'v2_no_imaging':
        # V2: no-imaging patients
        has_imaging = cohort_index.get('has_imaging', False)
        if isinstance(has_imaging, pd.Series):
            cohort_index = cohort_index[cohort_index['has_imaging'] == False]
        else:
            # Check imaging_modalities or dicom_series
            has_modalities = cohort_index.get('imaging_modalities', pd.Series([], dtype=object)).apply(
                lambda x: isinstance(x, (list, str)) and (('MR' in str(x)) or ('MG' in str(x))) if pd.notna(x) else False
            )
            has_dicom = cohort_index.get('dicom_series', pd.Series([], dtype=object)).apply(
                lambda x: pd.notna(x) and x != '{}' and x != '' if isinstance(x, str) else False
            )
            cohort_index = cohort_index[~(has_modalities | has_dicom)]
        logger.info(f"V2 cohort (no-imaging): {len(cohort_index)} patients")
    
    # Get common patients
    patient_ids = set(cohort_index['patient_id'].unique())
    patient_ids = patient_ids & set(clinical_table.index) & set(gene_set_table.index)
    
    cohort_index = cohort_index[cohort_index['patient_id'].isin(patient_ids)]
    clinical_table = clinical_table.loc[list(patient_ids)]
    gene_set_table = gene_set_table.loc[list(patient_ids)]
    
    logger.info(f"Common patients across all modalities: {len(patient_ids)}")
    
    return cohort_index, clinical_table, gene_set_table


def extract_patient_id(sample_barcode: str) -> str:
    """TCGA 샘플 바코드에서 Patient ID 추출 (첫 12자)"""
    parts = sample_barcode.split("-")
    if len(parts) >= 3:
        return "-".join(parts[:3])
    return sample_barcode


def extract_stage_labels(cohort_index: pd.DataFrame, clinical_table: pd.DataFrame) -> pd.Series:
    """Extract stage labels from clinical table."""
    import re
    
    # Try to find stage column
    stage_keywords = ['ajcc_pathologic_stage', 'pathologic_stage', 'stage', 'clinical_stage']
    stage_col = None
    
    for keyword in stage_keywords:
        for col in clinical_table.columns:
            if keyword.lower() in col.lower():
                stage_col = col
                break
        if stage_col:
            break
    
    if not stage_col:
        logger.warning("No stage column found, using 'Unknown' for all")
        patient_ids = cohort_index['patient_id'].values
        return pd.Series('Unknown', index=patient_ids)
    
    # Normalize stage values (matching LabelManager logic)
    def normalize_stage(val):
        if pd.isna(val) or val == '':
            return 'Unknown'
        
        val_str = str(val).strip()
        
        # Pattern matching
        if re.search(r'stage\s*[i1]', val_str, re.IGNORECASE):
            return 'Stage I'
        elif re.search(r'stage\s*[i1]{2,2}', val_str, re.IGNORECASE) or re.search(r'stage\s*2', val_str, re.IGNORECASE):
            return 'Stage II'
        elif re.search(r'stage\s*[i1]{3,3}', val_str, re.IGNORECASE) or re.search(r'stage\s*3', val_str, re.IGNORECASE):
            return 'Stage III'
        elif re.search(r'stage\s*[i1]{4,4}', val_str, re.IGNORECASE) or re.search(r'stage\s*4', val_str, re.IGNORECASE):
            return 'Stage IV'
        else:
            return 'Unknown'
    
    patient_ids = cohort_index['patient_id'].values
    # Handle case where patient_id might not be in clinical_table index
    if isinstance(clinical_table.index, pd.Index) and 'patient_id' in clinical_table.index.names:
        stages = clinical_table.loc[patient_ids, stage_col].apply(normalize_stage)
    else:
        # If patient_id is a column
        if 'patient_id' in clinical_table.columns:
            clinical_subset = clinical_table[clinical_table['patient_id'].isin(patient_ids)]
            stages = clinical_subset.set_index('patient_id').loc[patient_ids, stage_col].apply(normalize_stage)
        else:
            # Try to use index directly
            stages = clinical_table.loc[patient_ids, stage_col].apply(normalize_stage)
    
    return stages


def dirichlet_partition(
    labels: np.ndarray,
    n_clients: int,
    alpha: float,
    seed: int = 42
) -> List[np.ndarray]:
    """
    디리클레 분포를 사용한 non-IID 데이터 분할.
    
    각 클래스별로 Dirichlet(alpha, ..., alpha) 분포에서 비율을 샘플링하여
    클래스별 데이터를 클라이언트에 분배합니다.
    
    Args:
        labels: 레이블 배열
        n_clients: 클라이언트 수
        alpha: 디리클레 분포의 concentration parameter (작을수록 더 non-IID)
        seed: 랜덤 시드
    
    Returns:
        각 클라이언트에 할당된 인덱스 배열 리스트
    """
    rng = np.random.default_rng(seed)
    idx_by_client = [[] for _ in range(n_clients)]
    classes = np.unique(labels)
    
    logger.info(f"Partitioning {len(labels)} samples across {n_clients} clients with alpha={alpha}")
    logger.info(f"Classes: {classes}")
    
    for c in classes:
        idx_c = np.where(labels == c)[0]
        rng.shuffle(idx_c)
        
        if len(idx_c) == 0:
            continue
        
        # 각 클라이언트에 대한 비율 샘플링 (Dirichlet 분포)
        props = rng.dirichlet(alpha=np.full(n_clients, alpha))
        
        # 비율을 개수로 변환
        counts = (props * len(idx_c)).astype(int)
        
        # 반올림 오차 보정
        drift = len(idx_c) - counts.sum()
        if drift != 0:
            # 나머지를 순차적으로 분배
            for i in range(abs(drift)):
                idx_to_update = i % n_clients
                counts[idx_to_update] += 1 if drift > 0 else -1
        
        # 데이터 분배
        start = 0
        for k in range(n_clients):
            end = start + counts[k]
            if end > start:
                idx_by_client[k].extend(idx_c[start:end].tolist())
            start = end
        
        logger.info(f"  Class {c}: {len(idx_c)} samples -> {[len([i for i in idx_by_client[j] if labels[i] == c]) for j in range(n_clients)]}")
    
    return [np.array(v, dtype=int) for v in idx_by_client]


def save_client_data(
    client_idx: int,
    patient_ids: List[str],
    cohort_index: pd.DataFrame,
    clinical_table: pd.DataFrame,
    gene_set_table: pd.DataFrame,
    output_dir: Path,
    variant: str
):
    """클라이언트별 데이터 저장."""
    client_name = f"site-{client_idx}"
    client_dir = output_dir / client_name
    client_dir.mkdir(parents=True, exist_ok=True)
    
    # Filter data for this client
    client_cohort = cohort_index[cohort_index['patient_id'].isin(patient_ids)].copy()
    client_clinical = clinical_table.loc[patient_ids].copy()
    client_gene = gene_set_table.loc[patient_ids].copy()
    
    # Save files
    client_cohort.to_parquet(client_dir / 'cohort_index.parquet', compression='snappy')
    client_cohort.to_csv(client_dir / 'cohort_index.csv', index=False)
    
    client_clinical.to_parquet(client_dir / 'clinical_table.parquet', compression='snappy')
    client_clinical.to_csv(client_dir / 'clinical_table.csv')
    
    client_gene.to_parquet(client_dir / 'gene_set_table.parquet', compression='snappy')
    client_gene.to_csv(client_dir / 'gene_set_table.csv')
    
    logger.info(f"  Saved {client_name}: {len(patient_ids)} patients")
    
    return {
        'n_patients': len(patient_ids),
        'cohort_index_file': str(client_dir / 'cohort_index.parquet'),
        'clinical_table_file': str(client_dir / 'clinical_table.parquet'),
        'gene_set_table_file': str(client_dir / 'gene_set_table.parquet'),
    }


def main():
    parser = argparse.ArgumentParser(
        description="Prepare multimodal dataset and split into clients using Dirichlet distribution"
    )
    parser.add_argument('--cohort_index', type=str, required=True,
                       help='Path to cohort_index.parquet or .csv')
    parser.add_argument('--clinical_table', type=str, required=True,
                       help='Path to clinical_table.parquet or .csv')
    parser.add_argument('--gene_set_table', type=str, required=True,
                       help='Path to expression_matrix.parquet or gene_set_table.parquet')
    parser.add_argument('--output_dir', type=str, required=True,
                       help='Output directory for client splits')
    parser.add_argument('--n_clients', type=int, required=True,
                       help='Number of clients')
    parser.add_argument('--alpha', type=float, default=0.3,
                       help='Dirichlet concentration parameter (lower = more non-IID, default: 0.3)')
    parser.add_argument('--variant', type=str, default='v1_imaging',
                       choices=['v1_imaging', 'v2_no_imaging'],
                       help='Variant: v1_imaging or v2_no_imaging')
    parser.add_argument('--seed', type=int, default=42,
                       help='Random seed')
    parser.add_argument('--train_ratio', type=float, default=0.7,
                       help='Train split ratio (default: 0.7)')
    parser.add_argument('--val_ratio', type=float, default=0.15,
                       help='Validation split ratio (default: 0.15)')
    parser.add_argument('--test_ratio', type=float, default=0.15,
                       help='Test split ratio (default: 0.15)')
    parser.add_argument('--pam50_file', type=str, default=None,
                       help='Path to PAM50 labels file (optional, for subtype labels)')
    parser.add_argument('--brca_labels_file', type=str, default=None,
                       help='Path to BRCA-data-with-integer-labels.csv (optional, highest priority for subtype labels)')
    
    args = parser.parse_args()
    
    # Create output directory
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Load data
    cohort_index, clinical_table, gene_set_table = load_multimodal_data(
        args.cohort_index,
        args.clinical_table,
        args.gene_set_table,
        variant=args.variant
    )
    
    # Extract labels (stage)
    patient_ids = cohort_index['patient_id'].values
    stages = extract_stage_labels(cohort_index, clinical_table)
    stage_labels = stages.values
    
    # Create label mapping
    unique_stages = np.unique(stage_labels)
    stage_to_idx = {s: i for i, s in enumerate(unique_stages)}
    label_indices = np.array([stage_to_idx[s] for s in stage_labels])
    
    logger.info(f"Stage distribution: {pd.Series(stage_labels).value_counts().to_dict()}")
    
    # Load BRCA labels file if provided (highest priority for subtype)
    brca_labels_mapping = None
    if args.brca_labels_file:
        try:
            df_brca = pd.read_csv(args.brca_labels_file)
            if 'sample_id' in df_brca.columns:
                # Find label column
                label_col = None
                for col in ['Subtype', 'subtype', 'label', 'Label', 'LABEL']:
                    if col in df_brca.columns:
                        label_col = col
                        break
                
                if label_col:
                    df_brca['patient_id'] = df_brca['sample_id'].apply(extract_patient_id)
                    brca_labels_mapping = df_brca.groupby('patient_id')[label_col].first().to_dict()
                    logger.info(f"Loaded BRCA labels for {len(brca_labels_mapping)} patients")
                    logger.info(f"Subtype distribution: {df_brca[label_col].value_counts().sort_index().to_dict()}")
        except Exception as e:
            logger.warning(f"Could not load BRCA labels file: {e}")
    
    # Load PAM50 if provided (for subtype information in summary)
    pam50_mapping = None
    if args.pam50_file:
        try:
            df_pam50 = pd.read_csv(args.pam50_file, sep='\t')
            if 'Sample' in df_pam50.columns and 'PAM50' in df_pam50.columns:
                df_pam50['patient_id'] = df_pam50['Sample'].apply(extract_patient_id)
                pam50_mapping = df_pam50.groupby('patient_id')['PAM50'].first().to_dict()
                logger.info(f"Loaded PAM50 labels for {len(pam50_mapping)} patients")
        except Exception as e:
            logger.warning(f"Could not load PAM50 file: {e}")
    
    # Dirichlet partition
    client_indices = dirichlet_partition(
        label_indices,
        args.n_clients,
        args.alpha,
        args.seed
    )
    
    # Validate split ratios
    total_ratio = args.train_ratio + args.val_ratio + args.test_ratio
    if abs(total_ratio - 1.0) > 1e-6:
        raise ValueError(f"Train/Val/Test ratios must sum to 1.0, got {total_ratio}")
    
    # Create train/val/test split for each client
    summary = {
        'variant': args.variant,
        'n_clients': args.n_clients,
        'alpha': args.alpha,
        'seed': args.seed,
        'total_patients': len(patient_ids),
        'train_ratio': args.train_ratio,
        'val_ratio': args.val_ratio,
        'test_ratio': args.test_ratio,
        'stage_classes': unique_stages.tolist(),
        'clients': {}
    }
    
    for client_idx, indices in enumerate(client_indices, start=1):
        client_patient_ids = patient_ids[indices].tolist()
        client_stages = stage_labels[indices]
        
        # Train/val/test split with stratification
        client_stage_labels = [stage_labels[np.where(patient_ids == pid)[0][0]] for pid in client_patient_ids]
        unique_client_stages = np.unique(client_stage_labels)
        
        # Handle edge cases for small client sizes
        if len(client_patient_ids) == 1:
            # 샘플이 1개인 경우 모두 train으로
            train_ids = client_patient_ids
            val_ids = []
            test_ids = []
            logger.info(f"  Client {client_idx} has only 1 sample, using all for training")
        elif len(client_patient_ids) == 2:
            # 샘플이 2개인 경우 train/test로 분리
            train_ids = [client_patient_ids[0]]
            val_ids = []
            test_ids = [client_patient_ids[1]]
            logger.info(f"  Client {client_idx} has only 2 samples, splitting train/test")
        elif len(client_patient_ids) == 3:
            # 샘플이 3개인 경우 train/val/test로 분리
            train_ids = [client_patient_ids[0]]
            val_ids = [client_patient_ids[1]]
            test_ids = [client_patient_ids[2]]
            logger.info(f"  Client {client_idx} has only 3 samples, splitting train/val/test")
        else:
            # 4개 이상인 경우 정상 3-way split
            try:
                if len(unique_client_stages) > 1:
                    # Stratified 3-way split: 먼저 train과 나머지로 분리
                    train_ids, temp_ids = train_test_split(
                        client_patient_ids,
                        test_size=(args.val_ratio + args.test_ratio),
                        random_state=args.seed + client_idx,
                        stratify=client_stage_labels
                    )
                    # 나머지를 val과 test로 분리
                    temp_labels = [stage_labels[np.where(patient_ids == pid)[0][0]] for pid in temp_ids]
                    if len(temp_ids) > 1 and len(set(temp_labels)) > 1:
                        val_ids, test_ids = train_test_split(
                            temp_ids,
                            test_size=args.test_ratio / (args.val_ratio + args.test_ratio),
                            random_state=args.seed + client_idx + 1000,
                            stratify=temp_labels
                        )
                    else:
                        # Simple split without stratification
                        val_ids, test_ids = train_test_split(
                            temp_ids,
                            test_size=args.test_ratio / (args.val_ratio + args.test_ratio),
                            random_state=args.seed + client_idx + 1000
                        )
                else:
                    # Simple 3-way split without stratification
                    train_ids, temp_ids = train_test_split(
                        client_patient_ids,
                        test_size=(args.val_ratio + args.test_ratio),
                        random_state=args.seed + client_idx
                    )
                    val_ids, test_ids = train_test_split(
                        temp_ids,
                        test_size=args.test_ratio / (args.val_ratio + args.test_ratio),
                        random_state=args.seed + client_idx + 1000
                    )
            except ValueError as e:
                # Fallback to simple split if stratification fails
                logger.warning(f"Stratification failed for client {client_idx}, using simple split: {e}")
                try:
                    train_ids, temp_ids = train_test_split(
                        client_patient_ids,
                        test_size=(args.val_ratio + args.test_ratio),
                        random_state=args.seed + client_idx
                    )
                    val_ids, test_ids = train_test_split(
                        temp_ids,
                        test_size=args.test_ratio / (args.val_ratio + args.test_ratio),
                        random_state=args.seed + client_idx + 1000
                    )
                except ValueError as e2:
                    # 최후의 수단: train만 사용
                    logger.warning(f"Split failed for client {client_idx}, using all for training: {e2}")
                    train_ids = client_patient_ids
                    val_ids = []
                    test_ids = []
        
        # Save client data
        client_info = save_client_data(
            client_idx,
            client_patient_ids,
            cohort_index,
            clinical_table,
            gene_set_table,
            output_dir,
            args.variant
        )
        
        # Save train/val/test splits
        client_dir = output_dir / f"site-{client_idx}"
        pd.DataFrame({'patient_id': train_ids}).to_csv(
            client_dir / 'train_patients.csv', index=False
        )
        pd.DataFrame({'patient_id': val_ids}).to_csv(
            client_dir / 'val_patients.csv', index=False
        )
        pd.DataFrame({'patient_id': test_ids}).to_csv(
            client_dir / 'test_patients.csv', index=False
        )
        
        # Statistics
        train_stages = [stage_labels[patient_ids == pid][0] for pid in train_ids] if train_ids else []
        val_stages = [stage_labels[patient_ids == pid][0] for pid in val_ids] if val_ids else []
        test_stages = [stage_labels[patient_ids == pid][0] for pid in test_ids] if test_ids else []
        
        client_summary = {
            **client_info,
            'n_train': len(train_ids),
            'n_val': len(val_ids),
            'n_test': len(test_ids),
            'train_stage_dist': pd.Series(train_stages).value_counts().to_dict() if train_stages else {},
            'val_stage_dist': pd.Series(val_stages).value_counts().to_dict() if val_stages else {},
            'test_stage_dist': pd.Series(test_stages).value_counts().to_dict() if test_stages else {},
            'total_stage_dist': pd.Series(client_stages).value_counts().to_dict(),
        }
        
        # Add BRCA labels distribution if available (highest priority)
        if brca_labels_mapping:
            client_brca_labels = [brca_labels_mapping.get(pid, 'Unknown') for pid in client_patient_ids]
            client_summary['brca_subtype_dist'] = pd.Series(client_brca_labels).value_counts().to_dict()
        
        # Add PAM50 distribution if available
        if pam50_mapping:
            client_pam50 = [pam50_mapping.get(pid, 'Unknown') for pid in client_patient_ids]
            client_summary['pam50_dist'] = pd.Series(client_pam50).value_counts().to_dict()
        
        summary['clients'][f'site-{client_idx}'] = client_summary
    
    # Save summary
    summary_file = output_dir / 'summary.json'
    with open(summary_file, 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    
    logger.info(f"\n{'='*60}")
    logger.info("Summary:")
    logger.info(f"  Variant: {args.variant}")
    logger.info(f"  Total patients: {len(patient_ids)}")
    logger.info(f"  Number of clients: {args.n_clients}")
    logger.info(f"  Dirichlet alpha: {args.alpha}")
    logger.info(f"  Output directory: {output_dir}")
    logger.info(f"{'='*60}\n")
    
    # Print client statistics
    for client_name, client_info in summary['clients'].items():
        logger.info(f"{client_name}:")
        logger.info(f"  Total patients: {client_info['n_patients']}")
        logger.info(f"  Train: {client_info['n_train']}, Val: {client_info['n_val']}, Test: {client_info['n_test']}")
        logger.info(f"  Stage distribution: {client_info['total_stage_dist']}")
    
    logger.info(f"\nSummary saved to: {summary_file}")
    
    # Create patient_to_site_mapping.csv with split information
    patient_mapping = []
    for client_name, client_info in summary['clients'].items():
        site_id = client_name
        
        # Read train/val/test patient lists
        client_dir = output_dir / client_name
        train_df = pd.read_csv(client_dir / 'train_patients.csv')
        val_df = pd.read_csv(client_dir / 'val_patients.csv')
        test_df = pd.read_csv(client_dir / 'test_patients.csv')
        
        # Add train patients
        for pid in train_df['patient_id'].values:
            patient_mapping.append({
                'patient_id': pid,
                'site_id': site_id,
                'split': 'train'
            })
        
        # Add val patients
        for pid in val_df['patient_id'].values:
            patient_mapping.append({
                'patient_id': pid,
                'site_id': site_id,
                'split': 'val'
            })
        
        # Add test patients
        for pid in test_df['patient_id'].values:
            patient_mapping.append({
                'patient_id': pid,
                'site_id': site_id,
                'split': 'test'
            })
    
    # Save patient mapping CSV
    mapping_df = pd.DataFrame(patient_mapping)
    mapping_df = mapping_df.sort_values(['site_id', 'split', 'patient_id'])
    mapping_file = output_dir / 'patient_to_site_mapping.csv'
    mapping_df.to_csv(mapping_file, index=False)
    logger.info(f"Patient-to-site mapping saved to: {mapping_file}")
    
    # Create site-*.csv files for NVFlare compatibility
    # Each site-{i}.csv is a copy of the site's cohort_index.csv
    for client_name in summary['clients'].keys():
        site_id = client_name
        client_dir = output_dir / client_name
        cohort_csv = client_dir / 'cohort_index.csv'
        site_csv = output_dir / f'{site_id}.csv'
        
        if cohort_csv.exists():
            import shutil
            shutil.copy2(cohort_csv, site_csv)
            logger.info(f"Created {site_csv.name} for NVFlare compatibility")
        else:
            logger.warning(f"Cohort CSV not found for {client_name}, skipping site-*.csv creation")


if __name__ == '__main__':
    main()

