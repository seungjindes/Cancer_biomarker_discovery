"""
TCGA-BRCA 데이터 전처리 스크립트

Xena gene expression 데이터와 TCIA 이미지 데이터를 매칭하여 pairs CSV를 생성합니다.
"""
import argparse
import os
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from tqdm import tqdm


def extract_case_id(sample_id: str) -> str:
    """
    TCGA 샘플 ID에서 case ID를 추출합니다.
    
    예: TCGA-D8-A146-01A -> TCGA-D8-A146
    """
    parts = sample_id.split("-")
    if len(parts) >= 3:
        return "-".join(parts[:3])
    return sample_id


def extract_sample_type(sample_id: str) -> str:
    """
    TCGA 샘플 ID에서 sample type을 추출합니다.
    
    예: TCGA-D8-A146-01A -> 01 (tumor)
    """
    parts = sample_id.split("-")
    if len(parts) >= 4:
        return parts[3][:2]
    return ""


def is_tumor_sample(sample_id: str) -> bool:
    """샘플이 tumor인지 확인합니다 (01-09: tumor, 10-19: normal)."""
    sample_type = extract_sample_type(sample_id)
    if sample_type:
        try:
            st = int(sample_type)
            return 1 <= st <= 9
        except ValueError:
            return False
    return False


def load_xena_data(xena_file: str, gene_mapping_file: Optional[str] = None) -> pd.DataFrame:
    """
    Xena 데이터를 로드하고 전처리합니다.
    
    Args:
        xena_file: Xena TSV 파일 경로
        gene_mapping_file: Gene mapping 파일 경로 (선택사항)
    
    Returns:
        전처리된 데이터프레임 (행: genes, 열: samples)
    """
    print(f"[로딩 중] Xena 데이터: {xena_file}")
    df = pd.read_csv(xena_file, sep='\t', index_col=0)
    print(f"[완료] 로드 완료: {df.shape[0]} genes, {df.shape[1]} samples")
    
    # Gene ID를 gene symbol로 변환 (선택사항)
    if gene_mapping_file and os.path.exists(gene_mapping_file):
        print(f"[로딩 중] Gene mapping: {gene_mapping_file}")
        gene_map = pd.read_csv(gene_mapping_file, sep='\t')
        # gene_map의 구조에 따라 매핑 수행
        # 여기서는 기본적으로 gene ID를 그대로 사용
        print("[완료] Gene mapping 로드 완료")
    
    return df


def find_image_paths(tcia_dir: str, case_id: str) -> List[str]:
    """
    TCIA 디렉토리에서 특정 case ID에 해당하는 이미지 경로를 찾습니다.
    
    Args:
        tcia_dir: TCIA 데이터 디렉토리
        case_id: TCGA case ID (예: TCGA-D8-A146)
    
    Returns:
        이미지 파일 경로 리스트
    """
    tcia_path = Path(tcia_dir)
    image_paths = []
    
    # TCIA 데이터 구조에 따라 경로 탐색
    # 일반적인 구조: tcia_dir/case_id/... 또는 tcia_dir/.../case_id/...
    for pattern in [
        f"**/{case_id}/**/*.dcm",
        f"**/{case_id}/**/*.DCM",
        f"**/{case_id}*/**/*.dcm",
        f"**/{case_id}*/**/*.DCM",
    ]:
        image_paths.extend(list(tcia_path.glob(pattern)))
    
    # 중복 제거 및 정렬
    image_paths = sorted(list(set(str(p) for p in image_paths)))
    
    return image_paths


def create_omics_vector(
    xena_df: pd.DataFrame,
    sample_id: str,
    method: str = "mean"
) -> Optional[np.ndarray]:
    """
    특정 샘플에 대한 omics 벡터를 생성합니다.
    
    Args:
        xena_df: Xena 데이터프레임
        sample_id: TCGA 샘플 ID
        method: 벡터 생성 방법 ("mean", "max", "sample")
            - "mean": 같은 case의 모든 샘플 평균
            - "max": 같은 case의 모든 샘플 중 최대값
            - "sample": 해당 샘플만 사용
    
    Returns:
        Omics 벡터 (numpy array) 또는 None
    """
    case_id = extract_case_id(sample_id)
    
    # 같은 case의 모든 샘플 찾기
    case_samples = [col for col in xena_df.columns if extract_case_id(col) == case_id]
    
    if not case_samples:
        return None
    
    if method == "mean":
        # 같은 case의 모든 샘플 평균
        vec = xena_df[case_samples].mean(axis=1).values
    elif method == "max":
        # 같은 case의 모든 샘플 중 최대값
        vec = xena_df[case_samples].max(axis=1).values
    elif method == "sample":
        # 해당 샘플만 사용
        if sample_id in xena_df.columns:
            vec = xena_df[sample_id].values
        else:
            return None
    else:
        raise ValueError(f"Unknown method: {method}")
    
    return vec.astype(np.float32)


def create_pairs_csv(
    xena_file: str,
    tcia_dir: str,
    output_csv: str,
    output_omics_dir: str,
    gene_mapping_file: Optional[str] = None,
    filter_tumor_only: bool = True,
    omics_method: str = "mean",
    min_images: int = 1
):
    """
    Xena 데이터와 TCIA 이미지 데이터를 매칭하여 pairs CSV를 생성합니다.
    
    Args:
        xena_file: Xena TSV 파일 경로
        tcia_dir: TCIA 이미지 데이터 디렉토리
        output_csv: 출력 pairs CSV 파일 경로
        output_omics_dir: Omics 벡터를 저장할 디렉토리
        gene_mapping_file: Gene mapping 파일 경로 (선택사항)
        filter_tumor_only: Tumor 샘플만 사용할지 여부
        omics_method: Omics 벡터 생성 방법
        min_images: 최소 이미지 개수
    """
    # 디렉토리 생성
    output_omics_dir = Path(output_omics_dir)
    output_omics_dir.mkdir(parents=True, exist_ok=True)
    
    # Xena 데이터 로드
    xena_df = load_xena_data(xena_file, gene_mapping_file)
    
    # 샘플 필터링
    samples = list(xena_df.columns)
    if filter_tumor_only:
        samples = [s for s in samples if is_tumor_sample(s)]
        print(f"[필터링] Tumor 샘플만 사용: {len(samples)} samples")
    
    # Pairs 생성
    pairs = []
    case_to_samples: Dict[str, List[str]] = {}
    
    # Case별로 샘플 그룹화
    for sample_id in samples:
        case_id = extract_case_id(sample_id)
        if case_id not in case_to_samples:
            case_to_samples[case_id] = []
        case_to_samples[case_id].append(sample_id)
    
    print(f"[처리 중] {len(case_to_samples)} cases")
    
    # 각 case에 대해 처리
    for case_id, sample_ids in tqdm(case_to_samples.items(), desc="Processing cases"):
        # 이미지 경로 찾기
        image_paths = find_image_paths(tcia_dir, case_id)
        
        if len(image_paths) < min_images:
            continue
        
        # Omics 벡터 생성 (첫 번째 샘플 사용)
        sample_id = sample_ids[0]
        omics_vec = create_omics_vector(xena_df, sample_id, method=omics_method)
        
        if omics_vec is None:
            continue
        
        # Omics 벡터 저장
        omics_file = output_omics_dir / f"{case_id}.npy"
        np.save(omics_file, omics_vec)
        
        # 이미지 경로 결정
        # 여러 이미지가 있는 경우 첫 번째 이미지 또는 디렉토리 경로 사용
        if len(image_paths) == 1:
            img_path = image_paths[0]
        else:
            # 여러 이미지가 있는 경우 디렉토리 경로 사용
            img_dir = Path(image_paths[0]).parent
            img_path = str(img_dir)
        
        # Label 결정 (여기서는 간단히 0으로 설정, 실제로는 subtype 등 사용)
        label = 0
        
        # 상대 경로로 변환
        img_path_rel = os.path.relpath(img_path, start=Path(output_csv).parent)
        omics_path_rel = os.path.relpath(omics_file, start=Path(output_csv).parent)
        
        pairs.append({
            "case_id": case_id,
            "label": label,
            "img_path": img_path_rel,
            "omics_path": omics_path_rel
        })
    
    # DataFrame 생성 및 저장
    df_pairs = pd.DataFrame(pairs)
    df_pairs.to_csv(output_csv, index=False)
    
    print(f"\n[완료] Pairs CSV 생성 완료: {output_csv}")
    print(f"  - 총 {len(df_pairs)} pairs")
    print(f"  - Omics 벡터 차원: {omics_vec.shape[0] if omics_vec is not None else 'N/A'}")
    print(f"  - Omics 벡터 저장 위치: {output_omics_dir}")


def main():
    parser = argparse.ArgumentParser(
        description="TCGA-BRCA 데이터 전처리 및 pairs CSV 생성",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    parser.add_argument(
        "--xena_file",
        type=str,
        required=True,
        help="Xena TSV 파일 경로"
    )
    parser.add_argument(
        "--tcia_dir",
        type=str,
        required=True,
        help="TCIA 이미지 데이터 디렉토리"
    )
    parser.add_argument(
        "--output_csv",
        type=str,
        required=True,
        help="출력 pairs CSV 파일 경로"
    )
    parser.add_argument(
        "--output_omics_dir",
        type=str,
        required=True,
        help="Omics 벡터를 저장할 디렉토리"
    )
    parser.add_argument(
        "--gene_mapping_file",
        type=str,
        default=None,
        help="Gene mapping 파일 경로 (선택사항)"
    )
    parser.add_argument(
        "--filter_tumor_only",
        action="store_true",
        default=True,
        help="Tumor 샘플만 사용 (기본값: True)"
    )
    parser.add_argument(
        "--omics_method",
        type=str,
        choices=["mean", "max", "sample"],
        default="mean",
        help="Omics 벡터 생성 방법 (기본값: mean)"
    )
    parser.add_argument(
        "--min_images",
        type=int,
        default=1,
        help="최소 이미지 개수 (기본값: 1)"
    )
    args = parser.parse_args()
    
    create_pairs_csv(
        xena_file=args.xena_file,
        tcia_dir=args.tcia_dir,
        output_csv=args.output_csv,
        output_omics_dir=args.output_omics_dir,
        gene_mapping_file=args.gene_mapping_file,
        filter_tumor_only=args.filter_tumor_only,
        omics_method=args.omics_method,
        min_images=args.min_images
    )


if __name__ == "__main__":
    main()

