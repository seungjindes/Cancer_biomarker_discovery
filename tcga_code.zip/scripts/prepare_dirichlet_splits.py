import argparse
import json
import os
from dataclasses import dataclass
from typing import Dict, List

import numpy as np
import pandas as pd


def dirichlet_partition(labels: np.ndarray, n_clients: int, alpha: float, seed: int) -> List[np.ndarray]:
    """Partition indices by label using Dirichlet(alpha) per class.

    This is a common non-IID simulation method:
    - For each class c, draw proportions p_c ~ Dirichlet(alpha,...,alpha)
    - Split indices of class c into client buckets by p_c

    Returns:
        list of index arrays, length = n_clients
    """
    rng = np.random.default_rng(seed)
    idx_by_client = [[] for _ in range(n_clients)]
    classes = np.unique(labels)

    for c in classes:
        idx_c = np.where(labels == c)[0]
        rng.shuffle(idx_c)

        # proportions for this class across clients
        props = rng.dirichlet(alpha=np.full(n_clients, alpha))

        # convert proportions to counts (ensure sum matches)
        counts = (props * len(idx_c)).astype(int)
        # fix rounding drift
        drift = len(idx_c) - counts.sum()
        for i in range(abs(drift)):
            counts[i % n_clients] += 1 if drift > 0 else -1

        start = 0
        for k in range(n_clients):
            end = start + counts[k]
            if end > start:
                idx_by_client[k].extend(idx_c[start:end].tolist())
            start = end

    return [np.array(v, dtype=int) for v in idx_by_client]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pairs_csv", type=str, required=True)
    ap.add_argument("--out_dir", type=str, required=True)
    ap.add_argument("--n_clients", type=int, required=True)
    ap.add_argument("--alpha", type=float, default=0.3)
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    df = pd.read_csv(args.pairs_csv)
    required = {"case_id", "label", "img_path", "omics_path"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"pairs_csv missing columns: {sorted(missing)}; required={sorted(required)}")

    labels = df["label"].to_numpy()
    parts = dirichlet_partition(labels, args.n_clients, args.alpha, args.seed)

    os.makedirs(args.out_dir, exist_ok=True)
    summary = {"n_clients": args.n_clients, "alpha": args.alpha, "seed": args.seed, "clients": {}}

    for i, idx in enumerate(parts, start=1):
        client_name = f"site-{i}"
        out_csv = os.path.join(args.out_dir, f"{client_name}.csv")
        sub = df.iloc[idx].copy()
        sub.to_csv(out_csv, index=False)
        counts = sub["label"].value_counts().to_dict()
        summary["clients"][client_name] = {"n_samples": int(len(sub)), "label_counts": {str(k): int(v) for k, v in counts.items()}}

    with open(os.path.join(args.out_dir, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    print(f"[OK] Wrote splits to: {args.out_dir}")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
