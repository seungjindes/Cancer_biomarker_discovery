#!/bin/bash

# NVFlare 실행 스크립트
# Docker 컨테이너 내에서 NVFlare를 실행하기 위한 헬퍼 스크립트

set -e

echo "=== NVFlare 실행 스크립트 ==="

# NVFlare가 설치되어 있는지 확인
if ! command -v nvflare &> /dev/null; then
    echo "NVFlare가 설치되어 있지 않습니다. 설치 중..."
    
    # NVFlare 서브모듈이 있는지 확인
    if [ -d "NVFlare" ] && [ "$(ls -A NVFlare)" ]; then
        echo "NVFlare 서브모듈에서 설치 중..."
        cd NVFlare
        pip install -e .
        cd ..
    else
        echo "NVFlare 서브모듈이 없습니다. pip로 설치 중..."
        pip install nvflare
    fi
fi

# NVFlare 버전 확인
echo "NVFlare 버전:"
nvflare --version

echo ""
echo "=== NVFlare 사용 가능한 명령어 ==="
echo ""
echo "1. POC (Proof of Concept) 워크스페이스 준비:"
echo "   uv run nvflare poc prepare -n <클라이언트 수>"
echo ""
echo "2. POC 시작:"
echo "   uv run nvflare poc start"
echo ""
echo "3. POC 중지:"
echo "   uv run nvflare poc stop"
echo ""
echo "4. NVFlare 프로젝트 생성:"
echo "   uv run nvflare provision -p <프로젝트 이름>"
echo ""
echo "5. 도움말 보기:"
echo "   uv run nvflare --help"
echo ""
echo "자세한 내용은 NVFlare 문서를 참조하세요: https://nvflare.readthedocs.io/"

