import argparse
import os

from nvflare.app_common.workflows.fedavg import FedAvg
from nvflare.app_common.widgets.intime_model_selector import IntimeModelSelector
from nvflare.app_opt.pt.job_config.model import PTModel
from nvflare.job_config.api import FedJob
from nvflare.job_config.script_runner import ScriptRunner

from src.models.gene_encoder import GeneSetMLPEncoder


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--job_root", type=str, default="/tmp/nvflare/jobs/job_config")
    ap.add_argument("--workspace", type=str, default="/tmp/nvflare/jobs/workdir")
    ap.add_argument("--n_clients", type=int, default=2)
    ap.add_argument("--num_rounds", type=int, default=2)
    ap.add_argument("--split_dir", type=str, required=True, help="Directory containing site-*.csv split files")
    ap.add_argument("--data_root", type=str, required=True, help="Root path that makes img/omics paths resolvable on each site")
    ap.add_argument("--omics_dim", type=int, required=True, help="Dimension of omics vectors (.npy) used by seq encoder")
    ap.add_argument("--export_only", action="store_true", help="If set, export job config only (no simulator run).")
    args = ap.parse_args()

    n_clients = args.n_clients
    num_rounds = args.num_rounds

    # 1) Create job
    job = FedJob(name="tcga_multimodal_omics_encoder_fedavg", min_clients=n_clients)

    # 2) Server workflow: FedAvg
    controller = FedAvg(num_clients=n_clients, num_rounds=num_rounds)
    job.to_server(controller)

    # 3) Initial global model: ONLY the gene encoder parameters
    # We'll create a dummy gene encoder to initialize
    # The actual model will be built in client_train.py
    init_gene_encoder = GeneSetMLPEncoder(
        input_dim=args.omics_dim,
        hidden_dim=256,
        output_dim=128,
        dropout=0.3
    )
    job.to_server(PTModel(init_gene_encoder))

    # 4) Optional model selection widget (expects clients to report a metric named "accuracy" in FLModel.meta)
    job.to_server(IntimeModelSelector(key_metric="accuracy"))

    # 5) Client training script (Client API)
    #    NOTE: {i} expands to 1..n_clients in ScriptRunner.
    train_script = "src/train/client_train.py"
    # Use absolute paths to avoid path issues
    split_dir_abs = os.path.abspath(args.split_dir)
    data_root_abs = os.path.abspath(args.data_root)
    config_path = os.path.abspath("configs/v1_imaging.yaml")
    
    # Note: site_id will be extracted from FL_CLIENT_NAME environment variable
    # NVFlare sets FL_CLIENT_NAME to 'site-1', 'site-2', etc.
    script_args = (
        f"--data_root {data_root_abs} "
        f"--split_dir {split_dir_abs} "
        f"--config {config_path} "
        f"--variant v1_imaging "
        f"--epochs 1 --batch_size 8 --lr 1e-4 "
        f"--num_workers 0 "
        f"--seed 42"
    )
    runner = ScriptRunner(script=train_script, script_args=script_args)
    job.to_clients(runner)

    os.makedirs(args.job_root, exist_ok=True)
    os.makedirs(args.workspace, exist_ok=True)

    # Export job config
    job.export_job(args.job_root)
    print(f"[OK] Exported job to: {args.job_root}")

    if not args.export_only:
        # Run simulator
        job.simulator_run(args.workspace, n_clients=n_clients)
        print(f"[OK] Simulator run finished. Workspace: {args.workspace}")


if __name__ == "__main__":
    main()
