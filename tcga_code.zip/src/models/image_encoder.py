"""
2D backbone with hierarchical attention pooling for MR/MG images (C1).
Supports ResNet and pretrained Vision Transformer (ViT) from checkpoint.
"""
import logging
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models

logger = logging.getLogger(__name__)


class HierarchicalAttentionPooling(nn.Module):
    """
    Hierarchical attention pooling with modality-type embeddings.
    
    Processes multiple images from a patient with attention pooling.
    """
    
    def __init__(self, input_dim: int, hidden_dim: int = 256, output_dim: int = 256):
        super().__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        
        # Modality embeddings (MR, MG)
        self.modality_embed = nn.Embedding(2, hidden_dim)  # 0=MR, 1=MG
        
        # Attention mechanism
        self.attention = nn.Sequential(
            nn.Linear(input_dim + hidden_dim, hidden_dim),
            nn.Tanh(),
            nn.Linear(hidden_dim, 1)
        )
        
        # Output projection
        self.output_proj = nn.Linear(input_dim + hidden_dim, output_dim)
    
    def forward(self, features: torch.Tensor, modality_ids: torch.Tensor) -> torch.Tensor:
        """
        Args:
            features: (B, N, input_dim) where N is number of images
            modality_ids: (B, N) modality IDs (0=MR, 1=MG)
        
        Returns:
            (B, output_dim) patient-level embedding
        """
        B, N, C = features.shape
        
        # Get modality embeddings
        mod_emb = self.modality_embed(modality_ids)  # (B, N, hidden_dim)
        
        # Concatenate features with modality embeddings
        x = torch.cat([features, mod_emb], dim=-1)  # (B, N, input_dim + hidden_dim)
        
        # Compute attention weights
        attn_weights = self.attention(x)  # (B, N, 1)
        attn_weights = F.softmax(attn_weights, dim=1)
        
        # Weighted sum
        x = (x * attn_weights).sum(dim=1)  # (B, input_dim + hidden_dim)
        
        # Output projection
        x = self.output_proj(x)  # (B, output_dim)
        
        return x


class MRMGHierarchicalImageEncoder(nn.Module):
    """
    2D backbone with hierarchical attention pooling for MR/MG images.
    
    Architecture:
    - Pretrained ResNet18/50 or Vision Transformer from checkpoint (frozen by default)
    - Hierarchical attention pooling with modality embeddings
    - Output: patient embedding z_i in R^256
    """
    
    def __init__(
        self,
        backbone: str = 'resnet18',
        pretrained: bool = True,
        freeze_backbone: bool = True,
        output_dim: int = 256,
        checkpoint_path: str = None
    ):
        super().__init__()
        self.backbone_name = backbone
        self.output_dim = output_dim
        self.checkpoint_path = checkpoint_path
        
        # Load from checkpoint if provided
        if checkpoint_path and Path(checkpoint_path).exists():
            logger.info(f"Loading image encoder from checkpoint: {checkpoint_path}")
            self.backbone, backbone_dim = self._load_from_checkpoint(checkpoint_path, freeze_backbone)
            self.is_vit = True
        else:
            # Load pretrained backbone (ResNet)
            if backbone == 'resnet18':
                backbone_model = models.resnet18(pretrained=pretrained)
                backbone_dim = 512  # ResNet18 feature dim
            elif backbone == 'resnet50':
                backbone_model = models.resnet50(pretrained=pretrained)
                backbone_dim = 2048  # ResNet50 feature dim
            else:
                raise ValueError(f"Unknown backbone: {backbone}")
            
            # Remove final layers
            self.backbone = nn.Sequential(*list(backbone_model.children())[:-2])
            self.is_vit = False
            
            # Freeze backbone if requested
            if freeze_backbone:
                for param in self.backbone.parameters():
                    param.requires_grad = False
        
        # Global average pooling (for ResNet)
        if not self.is_vit:
            self.global_pool = nn.AdaptiveAvgPool2d(1)
        else:
            # ViT doesn't need global pooling
            self.global_pool = None
        
        # Feature projection to consistent dim
        self.feature_proj = nn.Linear(backbone_dim, 256)
        
        # Hierarchical attention pooling
        self.attention_pool = HierarchicalAttentionPooling(
            input_dim=256,
            hidden_dim=256,
            output_dim=output_dim
        )
    
    def _load_from_checkpoint(self, checkpoint_path: str, freeze_backbone: bool = True):
        """Load Vision Transformer from checkpoint (supports 3D ViT)."""
        checkpoint = torch.load(checkpoint_path, map_location='cpu')
        state_dict = checkpoint.get('state_dict', checkpoint)
        arch = checkpoint.get('arch', 'unknown')
        
        logger.info(f"Loading checkpoint with architecture: {arch}")
        
        # Extract base_encoder keys
        base_encoder_dict = {}
        for key, value in state_dict.items():
            if key.startswith('base_encoder.'):
                new_key = key.replace('base_encoder.', '')
                base_encoder_dict[new_key] = value
        
        if not base_encoder_dict:
            raise ValueError(f"No 'base_encoder' found in checkpoint: {checkpoint_path}")
        
        # Check if it's a 3D ViT
        is_3d = 'vit_3d' in arch.lower() or '3d' in arch.lower()
        
        if is_3d:
            logger.info("Detected 3D ViT model. Creating 3D ViT wrapper.")
            # Create a custom 3D ViT wrapper
            from .vit_3d_wrapper import ViT3DWrapper
            vit_model = ViT3DWrapper(base_encoder_dict, freeze_backbone)
            backbone_dim = 768  # Default for base model
            return vit_model, backbone_dim
        else:
            # Try to load as standard 2D ViT using transformers
            try:
                from transformers import ViTModel, ViTConfig
                
                # Infer config from checkpoint
                hidden_size = 768  # Default
                if 'cls_token' in base_encoder_dict:
                    hidden_size = base_encoder_dict['cls_token'].shape[-1]
                
                num_layers = 12  # Default
                layer_keys = [k for k in base_encoder_dict.keys() if k.startswith('blocks.')]
                if layer_keys:
                    layer_nums = [int(k.split('.')[1]) for k in layer_keys if k.split('.')[1].isdigit()]
                    if layer_nums:
                        num_layers = max(layer_nums) + 1
                
                config = ViTConfig(
                    image_size=224,
                    patch_size=16,
                    num_channels=3,
                    hidden_size=hidden_size,
                    num_hidden_layers=num_layers,
                    num_attention_heads=12,
                    intermediate_size=3072,
                )
                
                # Create model
                vit_model = ViTModel(config)
                
                # Load weights (with flexibility for key mismatches)
                try:
                    vit_model.load_state_dict(base_encoder_dict, strict=False)
                    logger.info("Loaded 2D ViT model from checkpoint")
                except Exception as e:
                    logger.warning(f"Could not load all weights: {e}. Using partial loading.")
                    model_dict = vit_model.state_dict()
                    matching_dict = {k: v for k, v in base_encoder_dict.items() if k in model_dict}
                    model_dict.update(matching_dict)
                    vit_model.load_state_dict(model_dict)
                
                # Freeze if requested
                if freeze_backbone:
                    for param in vit_model.parameters():
                        param.requires_grad = False
                
                # Return the encoder part
                backbone = vit_model.encoder
                backbone_dim = config.hidden_size
                
                return backbone, backbone_dim
                
            except ImportError:
                raise NotImplementedError("ViT loading requires transformers package. Please install: pip install transformers")
    
    def forward(self, images: torch.Tensor, modality_ids: torch.Tensor) -> torch.Tensor:
        """
        Args:
            images: (B, N, C, H, W) batch of image sequences
            modality_ids: (B, N) modality IDs (0=MR, 1=MG)
        
        Returns:
            (B, output_dim) patient-level embedding
        """
        B, N, C, H, W = images.shape
        
        # Flatten batch and sequence dimensions
        images_flat = images.view(B * N, C, H, W)
        
        # Extract features with backbone
        if self.is_vit:
            # ViT forward pass (3D ViT wrapper handles 2D->3D conversion)
            # Input: (B*N, C, H, W) -> Output: (B*N, hidden_size)
            features = self.backbone(images_flat)  # (B*N, hidden_size)
        else:
            # ResNet forward pass
            features = self.backbone(images_flat)  # (B*N, backbone_dim, H', W')
            features = self.global_pool(features).squeeze(-1).squeeze(-1)  # (B*N, backbone_dim)
        
        # Project to consistent dim
        features = self.feature_proj(features)  # (B*N, 256)
        
        # Reshape back to (B, N, 256)
        features = features.view(B, N, 256)
        
        # Hierarchical attention pooling
        patient_embedding = self.attention_pool(features, modality_ids)  # (B, output_dim)
        
        return patient_embedding
    
    def forward_single_image(self, image: torch.Tensor, modality_id: int = 0) -> torch.Tensor:
        """
        Forward pass for single image (for inference).
        
        Args:
            image: (B, C, H, W) single image
            modality_id: modality ID (0=MR, 1=MG)
        
        Returns:
            (B, output_dim) image embedding
        """
        B, C, H, W = image.shape
        
        # Extract features
        features = self.backbone(image)  # (B, backbone_dim, H', W')
        features = self.global_pool(features).squeeze(-1).squeeze(-1)  # (B, backbone_dim)
        
        # Project
        features = self.feature_proj(features)  # (B, 256)
        
        # Add modality embedding and project
        modality_ids = torch.full((B,), modality_id, dtype=torch.long, device=image.device)
        mod_emb = self.attention_pool.modality_embed(modality_ids)  # (B, 256)
        
        x = torch.cat([features, mod_emb], dim=-1)  # (B, 512)
        x = self.attention_pool.output_proj(x)  # (B, output_dim)
        
        return x

