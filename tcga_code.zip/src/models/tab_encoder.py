"""
FT-Transformer encoder for clinical/tabular data (B1).
"""
import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class MultiHeadAttention(nn.Module):
    """Multi-head self-attention."""
    
    def __init__(self, dim: int, num_heads: int = 4, dropout: float = 0.2):
        super().__init__()
        assert dim % num_heads == 0
        
        self.dim = dim
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        
        self.qkv = nn.Linear(dim, dim * 3)
        self.proj = nn.Linear(dim, dim)
        self.dropout = nn.Dropout(dropout)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (B, N, dim) where N is sequence length
        
        Returns:
            (B, N, dim)
        """
        B, N, C = x.shape
        
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, self.head_dim).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]
        
        attn = (q @ k.transpose(-2, -1)) * (self.head_dim ** -0.5)
        attn = attn.softmax(dim=-1)
        attn = self.dropout(attn)
        
        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        x = self.proj(x)
        return x


class TransformerBlock(nn.Module):
    """Transformer block with pre-norm."""
    
    def __init__(self, dim: int, num_heads: int = 4, dropout: float = 0.2, mlp_ratio: int = 4):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = MultiHeadAttention(dim, num_heads, dropout)
        self.norm2 = nn.LayerNorm(dim)
        
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Linear(dim, mlp_hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(mlp_hidden_dim, dim),
            nn.Dropout(dropout),
        )
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.norm1(x))
        x = x + self.mlp(self.norm2(x))
        return x


class FTTransformerEncoder(nn.Module):
    """
    FT-Transformer encoder for clinical/tabular data.
    
    Architecture:
    - Input projection: Linear(input_dim, dim)
    - Positional encoding (learned)
    - 2 transformer blocks (depth=2)
    - Output: Global pooling -> Linear(dim, output_dim)
    """
    
    def __init__(
        self,
        input_dim: int,
        dim: int = 128,
        num_heads: int = 4,
        depth: int = 2,
        dropout: float = 0.2,
        output_dim: int = 128
    ):
        super().__init__()
        self.input_dim = input_dim
        self.dim = dim
        self.depth = depth
        
        # Input projection
        self.input_proj = nn.Linear(input_dim, dim)
        
        # Positional encoding (learned)
        self.pos_embed = nn.Parameter(torch.randn(1, 1000, dim))  # Max 1000 features
        
        # Transformer blocks
        self.blocks = nn.ModuleList([
            TransformerBlock(dim, num_heads, dropout)
            for _ in range(depth)
        ])
        
        self.norm = nn.LayerNorm(dim)
        
        # Output projection
        self.output_proj = nn.Linear(dim, output_dim)
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (B, N) where N is number of clinical features
        
        Returns:
            (B, output_dim) clinical embedding
        """
        B, N = x.shape
        
        # Project each feature to dim
        # x: (B, N) -> (B, N, 1) -> (B, N, dim)
        x = x.unsqueeze(-1)  # (B, N, 1)
        x = self.input_proj(x)  # (B, N, dim)
        
        # Add positional encoding (truncate if needed)
        if N <= self.pos_embed.shape[1]:
            pos = self.pos_embed[:, :N, :]
        else:
            # Interpolate if N > max_pos
            pos = F.interpolate(
                self.pos_embed.transpose(1, 2),
                size=N,
                mode='linear',
                align_corners=False
            ).transpose(1, 2)
        
        x = x + pos
        
        # Apply transformer blocks
        for block in self.blocks:
            x = block(x)
        
        x = self.norm(x)
        
        # Global pooling (mean)
        x = x.mean(dim=1)  # (B, dim)
        
        # Output projection
        x = self.output_proj(x)  # (B, output_dim)
        
        return x

