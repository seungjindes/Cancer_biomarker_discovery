import torch
import torch.nn as nn
import torchvision.models as tvm

from .global_seq_encoder import GlobalSeqEncoder


def build_image_encoder(name: str = "resnet18", feat_dim: int = 256, pretrained: bool = True) -> nn.Module:
    """Return an image feature extractor that outputs `feat_dim` features."""
    name = name.lower()
    if name == "resnet18":
        m = tvm.resnet18(weights=tvm.ResNet18_Weights.DEFAULT if pretrained else None)
        # Replace classifier with projection to feat_dim
        in_dim = m.fc.in_features
        m.fc = nn.Linear(in_dim, feat_dim)
        return m
    elif name == "vit_b_16":
        m = tvm.vit_b_16(weights=tvm.ViT_B_16_Weights.DEFAULT if pretrained else None)
        in_dim = m.heads.head.in_features
        m.heads.head = nn.Linear(in_dim, feat_dim)
        return m
    else:
        raise ValueError(f"Unsupported img encoder: {name}")


class MultiModalNet(nn.Module):
    """Client-side model: image encoder (frozen) + shared omics encoder + local fusion head."""

    def __init__(self, omics_dim: int, n_classes: int = 6, feat_dim: int = 256, img_encoder: str = "resnet18"):
        super().__init__()
        self.feat_dim = feat_dim
        self.img_encoder = build_image_encoder(img_encoder, feat_dim=feat_dim, pretrained=True)
        self.seq_encoder = GlobalSeqEncoder(omics_dim=omics_dim, feat_dim=feat_dim)
        self.head = nn.Sequential(
            nn.Linear(feat_dim * 2, 512),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(512, n_classes),
        )

    def freeze_image_encoder(self):
        for p in self.img_encoder.parameters():
            p.requires_grad = False

    def forward(self, x_img, x_omics):
        z_img = self.img_encoder(x_img)      # [B,feat_dim]
        z_seq = self.seq_encoder(x_omics)    # [B,feat_dim]
        z = torch.cat([z_img, z_seq], dim=1)
        return self.head(z)
