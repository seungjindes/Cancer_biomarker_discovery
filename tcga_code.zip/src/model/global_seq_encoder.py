import torch
import torch.nn as nn


class GlobalSeqEncoder(nn.Module):
    """Only the TCGA/omics encoder that will be shared/aggregated on the server."""

    def __init__(self, omics_dim: int, hidden: int = 512, feat_dim: int = 256):
        super().__init__()
        self.omics_dim = int(omics_dim)
        self.net = nn.Sequential(
            nn.Linear(self.omics_dim, hidden),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden, feat_dim),
        )

    def forward(self, x):
        return self.net(x)
